#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Operating characteristics of the v26 safe-policy-improvement gate on real labels.

Uses the v25 signal-audit states (16 calibrated-testbed episodes, 43 decision
states, every feasible cell branched to the full horizon on 3 independent CRN
tapes).  The gate sees what fitted policy iteration would store for a holdout
episode -- one tape, full horizon, all cells -- and every deployed rule is then
scored against the *other two tapes*, which the gate never saw.

Measured, over random episode-level splits:

* **Safety under the null.**  A model with no skill must be certified at most
  at the nominal family-wise rate ``alpha``.
* **Power.**  Models of known quality -- the held-tape truth plus Gaussian
  noise of increasing size -- show how the certification rate and the
  realized gain grow with within-state ranking quality.
* **The replica learner.**  A bootstrap ridge ensemble on the per-cell
  features, fitted to one-tape labels from the fit episodes under the v26
  branch allocation, is gated exactly as the GNN would be.

Whenever a rule is certified, its *true* holdout gain (held tapes) is
recorded, so false certifications are counted directly.

    python fpi_gate_validation.py --splits 400
"""

from __future__ import annotations

import argparse
import json
import pickle
import time

import numpy as np

import FittedPolicyIteration as FPI

STATES_PATH = "runs/nmcc_v25_signal_audit_states_20260921.pkl"


def load_states(path: str = STATES_PATH) -> list[dict]:
    with open(path, "rb") as handle:
        payload = pickle.load(handle)
    return list(payload["states"])


def base_action(state: dict) -> int:
    feasible = state["actions"]
    return int(feasible[int(np.argmax(state["scores"][feasible]))])


def full_values(state: dict, tapes) -> np.ndarray:
    """(A,) tape-mean full-horizon value, NaN off the feasible set."""
    out = np.full(state["mask"].size, np.nan)
    out[state["actions"]] = state["values"][list(tapes), :, -1].mean(axis=0)
    return out


def episode_labels(states: list[dict], seed: int, *, tapes, split: str) -> FPI.EpisodeLabels:
    decisions = []
    for index, state in enumerate(sorted((s for s in states if s["seed"] == seed),
                                         key=lambda s: s["t"])):
        values = full_values(state, tapes)[None, :]
        base = base_action(state)
        decisions.append(
            FPI.DecisionLabel(
                transition_index=index,
                decision_index=int(state["decision_index"]),
                simulation_time=int(state["t"]),
                feasible=state["mask"],
                values=values,
                wait_values=np.full(1, np.nan),
                outcomes=np.where(np.isfinite(values)[:, :, None], 0.0, np.nan)
                * np.ones((1, values.shape[1], 6)),
                wait_outcomes=np.full((1, 6), np.nan),
                base_action=base,
                executed_action=base,
                greedy_action=base,
                exhaustive=True,
            )
        )
    return FPI.EpisodeLabels(
        episode_id=f"audit-{seed}",
        family=FPI.ScenarioFamily("testbed", 800, 2, 0.25),
        split=split,
        contract_digest="audit",
        scenario_seed=int(seed),
        policy_seed=0,
        decisions=decisions,
    )


def ridge_ensemble(fit_states, members, rng, *, penalty=3.0, v26_budget=8):
    """Bootstrap ridge on within-state-centered cell features (the replica)."""
    rows_x, rows_y, rows_state = [], [], []
    for index, state in enumerate(fit_states):
        feasible = state["actions"]
        values = state["values"][0, :, -1]  # the one stored tape
        if state["decision_index"] >= 2 and feasible.size > v26_budget:
            base = base_action(state)
            keep = [int(np.flatnonzero(feasible == base)[0])]
            others = [i for i in range(feasible.size) if i != keep[0]]
            keep += list(rng.choice(others, size=v26_budget - 1, replace=False))
            columns = np.asarray(sorted(keep))
        else:
            columns = np.arange(feasible.size)
        x = state["X"][feasible[columns]]
        y = values[columns]
        rows_x.append(x - x.mean(axis=0))
        rows_y.append(y - y.mean())
        rows_state.append(np.full(columns.size, index))
    x = np.concatenate(rows_x)
    y = np.concatenate(rows_y)
    owner = np.concatenate(rows_state)
    scale_x = x.std(axis=0)
    scale_x[scale_x <= 1e-12] = 1.0
    x = x / scale_x
    scale_y = float(np.sqrt(np.mean([np.var(r) for r in rows_y if r.size > 1])))
    coefficients = []
    for _ in range(members):
        weights = rng.poisson(1.0, size=len(fit_states)).astype(float)[owner]
        a = x.T @ (x * weights[:, None]) + penalty * np.eye(x.shape[1])
        b = x.T @ (weights * y / scale_y)
        coefficients.append(np.linalg.solve(a, b))
    return np.stack(coefficients), scale_x, scale_y


def ridge_members(model, state) -> np.ndarray:
    """(members, A) per-member cell predictions (zero off the feasible set)."""
    coefficients, scale_x, _ = model
    feasible = state["actions"]
    x = state["X"][feasible]
    x = (x - x.mean(axis=0)) / scale_x
    predictions = np.full((coefficients.shape[0], state["mask"].size), 0.0)
    predictions[:, feasible] = coefficients @ x.T
    return predictions


def true_gain(states, actions, scale) -> float:
    """Equal-weight mean over holdout episodes of the per-episode sum of
    held-tape gains over the base cell, in family-normalized units."""
    per_episode: dict[int, float] = {}
    for state, action in zip(states, actions):
        truth = full_values(state, (1, 2))
        gain = (truth[action] - truth[base_action(state)]) / scale
        per_episode[state["seed"]] = per_episode.get(state["seed"], 0.0) + gain
    return float(np.mean(list(per_episode.values())))


def run(splits: int, holdout_episodes: int, draws: int, seed: int) -> dict:
    states = load_states()
    seeds = sorted({s["seed"] for s in states})
    rng = np.random.default_rng(seed)
    lambdas, betas = (0.0, 0.5, 2.0, 8.0), (0.0, 1.0)
    models = ["null", "oracle_noise_0.25", "oracle_noise_0.5", "oracle_noise_1", "oracle_noise_2",
              "replica_ridge"]
    records = {name: [] for name in models}
    for split in range(splits):
        order = rng.permutation(seeds)
        hold, fit = sorted(order[:holdout_episodes]), sorted(order[holdout_episodes:])
        fit_episodes = [episode_labels(states, s, tapes=(0,), split="fit") for s in fit]
        hold_episodes = [episode_labels(states, s, tapes=(0,), split="holdout") for s in hold]
        scales = FPI.family_scales(fit_episodes)
        gate_states, locations = FPI.GateStates.from_episodes(hold_episodes, scales)
        hold_states = [
            sorted((x for x in states if x["seed"] == hold[e]), key=lambda x: x["t"])[d]
            for e, d in locations
        ]
        scale = float(gate_states.scales[0])
        prior = np.stack([s["scores"] for s in hold_states])
        truth = np.stack([np.nan_to_num(full_values(s, (1, 2)) - np.nanmean(full_values(s, (1, 2))))
                          for s in hold_states]) / scale
        replica = ridge_ensemble([x for x in states if x["seed"] in set(fit)], 5, rng)
        for name in models:
            if name == "null":
                mu = rng.normal(size=truth.shape)
                sigma = np.zeros_like(mu)
            elif name.startswith("oracle"):
                noise = float(name.rsplit("_", 1)[1])
                members = truth[:, None, :] + noise * rng.normal(size=(truth.shape[0], 5, truth.shape[1]))
                mu, sigma = FPI.ensemble_advantage_statistics(members, gate_states.base_actions)
            else:
                members = np.stack([ridge_members(replica, s) for s in hold_states])
                mu, sigma = FPI.ensemble_advantage_statistics(members, gate_states.base_actions)
            model = FPI.ModelPredictions(name, prior, mu, sigma)
            result = FPI.safe_improvement_gate(
                gate_states, [model], lambdas=lambdas, betas=betas, alpha=0.10, draws=draws,
                rng=np.random.default_rng(rng.integers(2**32)), minimum_episodes=6,
            )
            selected = result.selected
            actions = FPI.rule_actions(prior, mu, sigma, gate_states.feasible,
                                       gate_states.base_actions, lam=selected.lam, beta=selected.beta)
            ungated = FPI.rule_actions(prior, mu, sigma, gate_states.feasible,
                                       gate_states.base_actions, lam=8.0, beta=0.0)
            quality = FPI.within_state_quality(mu, np.where(gate_states.feasible, truth, np.nan),
                                               gate_states.feasible, prior=prior)
            records[name].append(
                {
                    "certified": result.reason == "certified_improvement",
                    "lambda": selected.lam,
                    "beta": selected.beta,
                    "gate_estimate": selected.mean_gain,
                    "gate_lcb": selected.lcb,
                    "true_gain_deployed": true_gain(hold_states, actions, scale),
                    "true_gain_ungated": true_gain(hold_states, ungated, scale),
                    "rank_corr_vs_held_tapes": quality["rank_corr"],
                    "headroom_held_tapes": true_gain(
                        hold_states,
                        [int(np.nanargmax(full_values(s, (1, 2)))) for s in hold_states],
                        scale,
                    ),
                }
            )
    summary = {}
    for name, rows in records.items():
        certified = [r for r in rows if r["certified"]]
        summary[name] = {
            "splits": len(rows),
            "certification_rate": float(np.mean([r["certified"] for r in rows])),
            "false_certification_rate": float(
                np.mean([r["certified"] and r["true_gain_deployed"] <= 0.0 for r in rows])
            ),
            "mean_true_gain_when_certified": (
                float(np.mean([r["true_gain_deployed"] for r in certified])) if certified else None
            ),
            "mean_true_gain_deployed": float(np.mean([r["true_gain_deployed"] for r in rows])),
            "mean_true_gain_ungated_lambda8": float(np.mean([r["true_gain_ungated"] for r in rows])),
            "share_of_splits_ungated_harms": float(np.mean([r["true_gain_ungated"] < 0 for r in rows])),
            "share_of_splits_deployed_harms": float(np.mean([r["true_gain_deployed"] < 0 for r in rows])),
            "mean_rank_corr_vs_held_tapes": float(np.nanmean([r["rank_corr_vs_held_tapes"] for r in rows])),
            "mean_headroom_held_tapes": float(np.mean([r["headroom_held_tapes"] for r in rows])),
        }
    return {"summary": summary, "settings": {
        "splits": splits, "holdout_episodes": holdout_episodes, "draws": draws, "seed": seed,
        "lambda_grid": list(lambdas), "beta_grid": list(betas), "alpha": 0.10,
        "gate_labels": "tape 0, full horizon, all feasible cells",
        "truth": "mean of tapes 1 and 2, full horizon",
        "episodes": len(seeds), "states": len(states)}}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--splits", type=int, default=400)
    parser.add_argument("--holdout-episodes", type=int, default=8)
    parser.add_argument("--draws", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=20260922)
    parser.add_argument("--output", default="runs/nmcc_v26_fpi_gate_validation_20260922.json")
    args = parser.parse_args(argv)
    started = time.time()
    payload = run(args.splits, args.holdout_episodes, args.draws, args.seed)
    payload["wall_seconds"] = time.time() - started
    with open(args.output, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    print(json.dumps(payload["summary"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
