#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Torch-free tests for rollout-labelled fitted policy iteration (v26).

What is pinned here:

* the decision schedule: the historical grid rule is unchanged, and catch-up
  carries a blocked token forward without ever exceeding the accrued budget;
  branch continuations use the same rule, and WAIT still defers to the next
  scheduled epoch;
* labels: shape and consistency checks, exact paired gains, an atomic store
  bound to one label contract, and deterministic episode-level splits;
* scenario-family normalization with empirical-Bayes shrinkage;
* the decision rule (``lambda = 0`` is the base policy exactly) and the
  safe-policy-improvement gate: it certifies a model that is truly better on
  exhaustively labelled holdout states, refuses a model with no skill, refuses
  one that harms a family, and falls back to the base policy without enough
  holdout evidence;
* branch allocation, the paired learning-curve summary and the fitted policy
  iteration convergence criterion.
"""

import tempfile
import unittest

import numpy as np

import FittedPolicyIteration as FPI
import NMCCPolicyImprovement as PI
import nmcc_testbed
from DecisionInterface import RegionalObservationBuilder, RegionalShelterExecutor


def make_label(values, *, feasible=None, base=0, executed=None, greedy=None, exhaustive=None,
               transition_index=0, decision_index=0):
    values = np.asarray(values, dtype=np.float64)
    if values.ndim == 1:
        values = values[None, :]
    actions = values.shape[1]
    if feasible is None:
        feasible = np.isfinite(values[0])
    feasible = np.asarray(feasible, dtype=bool)
    if exhaustive is None:
        exhaustive = bool(np.array_equal(np.isfinite(values[0]), feasible))
    tapes = values.shape[0]
    outcomes = np.where(
        np.isfinite(values)[:, :, None], np.zeros((tapes, actions, 6)), np.nan
    )
    return FPI.DecisionLabel(
        transition_index=transition_index,
        decision_index=decision_index,
        simulation_time=1 + 10 * decision_index,
        feasible=feasible,
        values=values,
        wait_values=np.zeros(tapes),
        outcomes=outcomes,
        wait_outcomes=np.zeros((tapes, 6)),
        base_action=base,
        executed_action=base if executed is None else executed,
        greedy_action=base if greedy is None else greedy,
        exhaustive=exhaustive,
    )


def make_episode(decisions, *, family=None, split="fit", episode_id="e0", digest="d"):
    family = family or FPI.ScenarioFamily("city", 5000, 2, 0.5)
    return FPI.EpisodeLabels(
        episode_id=episode_id,
        family=family,
        split=split,
        contract_digest=digest,
        scenario_seed=1,
        policy_seed=2,
        decisions=list(decisions),
    )


class ScheduleTests(unittest.TestCase):
    def test_grid_rule_is_the_historical_rule(self):
        for t in range(0, 70):
            legacy = (t - 1) >= 0 and (t - 1) % 10 == 0
            self.assertEqual(
                PI.decision_due(t, first=1, interval=10, budget=5, deployed=0, catch_up=False),
                legacy,
            )
        self.assertFalse(PI.decision_due(11, first=1, interval=10, budget=5, deployed=5, catch_up=False))

    def test_catch_up_carries_a_blocked_token_forward(self):
        # Token accrued at t = 1 was blocked; it stays due until installed.
        for t in range(1, 11):
            self.assertTrue(PI.decision_due(t, first=1, interval=10, budget=5, deployed=0, catch_up=True))
        # Installed at t = 4: nothing is due again until the t = 11 epoch.
        for t in range(5, 11):
            self.assertFalse(PI.decision_due(t, first=1, interval=10, budget=5, deployed=1, catch_up=True))
        self.assertTrue(PI.decision_due(11, first=1, interval=10, budget=5, deployed=1, catch_up=True))

    def test_catch_up_never_exceeds_the_accrued_or_total_budget(self):
        self.assertEqual(PI.accrued_tokens(0, first=1, interval=10, budget=5), 0)
        self.assertEqual(PI.accrued_tokens(1, first=1, interval=10, budget=5), 1)
        self.assertEqual(PI.accrued_tokens(21, first=1, interval=10, budget=5), 3)
        self.assertEqual(PI.accrued_tokens(500, first=1, interval=10, budget=5), 5)
        self.assertFalse(PI.decision_due(59, first=1, interval=10, budget=5, deployed=5, catch_up=True))

    def test_wait_defers_to_the_next_scheduled_epoch(self):
        self.assertEqual(PI.next_scheduled_epoch(1, first=1, interval=10), 11)
        self.assertEqual(PI.next_scheduled_epoch(13, first=1, interval=10), 21)
        self.assertEqual(PI.next_scheduled_epoch(0, first=1, interval=10), 1)
        clock = PI.EpisodeClock(horizon=60, interval=10, budget=5, population=10, t=1,
                                catch_up=True, hold_until=11)
        self.assertFalse(clock.is_decision(2))
        self.assertTrue(clock.is_decision(11))
        self.assertTrue(clock.copy().catch_up)
        self.assertEqual(clock.copy().hold_until, 11)


class DescriptorAndSplitTests(unittest.TestCase):
    def test_descriptors_are_bounded_and_monotone_for_any_scenario(self):
        small = FPI.scenario_descriptor(5000, 1, 0.1)
        large = FPI.scenario_descriptor(250000, 50, 0.9)
        self.assertEqual(small.shape, (len(FPI.SCENARIO_FEATURE_NAMES),))
        self.assertTrue(np.all((small >= 0) & (small < 1)))
        self.assertTrue(np.all((large >= 0) & (large < 1)))
        self.assertTrue(np.all(large > small))
        self.assertEqual(float(FPI.scenario_descriptor(10, 0, 2.0)[0]), 1.0)

    def test_split_is_deterministic_and_close_to_the_requested_fractions(self):
        splits = [
            FPI.assign_split("c", seed, holdout_fraction=0.2, validation_fraction=0.1)
            for seed in range(4000)
        ]
        again = [
            FPI.assign_split("c", seed, holdout_fraction=0.2, validation_fraction=0.1)
            for seed in range(4000)
        ]
        self.assertEqual(splits, again)
        self.assertAlmostEqual(splits.count("holdout") / 4000, 0.2, delta=0.03)
        self.assertAlmostEqual(splits.count("validation") / 4000, 0.1, delta=0.03)
        with self.assertRaises(ValueError):
            FPI.assign_split("c", 1, holdout_fraction=0.6, validation_fraction=0.5)

    def test_bootstrap_weights_are_a_fixed_function_of_the_state(self):
        a = FPI.bootstrap_weights("ep", 2, 5)
        b = FPI.bootstrap_weights("ep", 2, 5)
        np.testing.assert_array_equal(a, b)
        self.assertFalse(np.array_equal(a, FPI.bootstrap_weights("ep", 3, 5)) and
                         np.array_equal(a, FPI.bootstrap_weights("other", 2, 5)))

    def test_grid_parser(self):
        self.assertEqual(FPI.parse_grid("0,0.5,2", name="g"), (0.0, 0.5, 2.0))
        with self.assertRaises(ValueError):
            FPI.parse_grid("1,0.5", name="g")
        with self.assertRaises(ValueError):
            FPI.parse_grid("", name="g")


class LabelTests(unittest.TestCase):
    def test_paired_gain_and_best_action(self):
        label = make_label([[0.1, 0.3, np.nan, 0.2], [0.2, 0.2, np.nan, 0.4]],
                           feasible=[True, True, True, True], base=0, greedy=3, exhaustive=False)
        np.testing.assert_allclose(label.advantage_vs_base()[[0, 1, 3]], [0.0, 0.1, 0.15])
        self.assertEqual(label.best_action, 3)
        self.assertAlmostEqual(label.gain(3), 0.15)
        self.assertEqual(label.branched_count, 3)
        self.assertTrue(np.isfinite(label.contrast_standard_error()[1]))

    def test_invalid_labels_are_rejected(self):
        with self.assertRaises(ValueError):  # base not branched
            make_label([0.1, np.nan], feasible=[True, True], base=1, exhaustive=False)
        with self.assertRaises(ValueError):  # infeasible cell branched
            make_label([0.1, 0.2], feasible=[True, False], exhaustive=False)
        with self.assertRaises(ValueError):  # claims exhaustive but is not
            make_label([0.1, np.nan], feasible=[True, True], exhaustive=True)
        with self.assertRaises(ValueError):  # tapes branch different cells
            make_label([[0.1, 0.2], [0.1, np.nan]], feasible=[True, True], exhaustive=False)

    def test_store_round_trip_commit_protocol_and_contract(self):
        with tempfile.TemporaryDirectory() as directory:
            store = FPI.LabelStore(directory, {"base": "route_saving", "v": 1})
            decisions = [
                make_label([0.1, 0.3, 0.2], base=0, greedy=1, transition_index=0),
                make_label([0.0, np.nan, 0.5], feasible=[True, True, True], base=0,
                           greedy=2, exhaustive=False, transition_index=1, decision_index=1),
            ]
            episode = make_episode(decisions, digest=store.digest, episode_id="abc")
            with self.assertRaises(FileNotFoundError):
                store.commit(episode)  # frames first
            with open(store.frames_path("abc"), "wb") as handle:
                handle.write(b"frames")
            self.assertEqual(store.records(), [])  # uncommitted is invisible
            store.commit(episode)
            with self.assertRaises(FileExistsError):
                store.commit(episode)
            records = store.records("fit")
            self.assertEqual([r["episode_id"] for r in records], ["abc"])
            loaded = store.load(records[0])
            self.assertEqual(loaded.family, episode.family)
            for a, b in zip(loaded.decisions, decisions):
                np.testing.assert_array_equal(a.values, b.values)
                self.assertEqual(a.exhaustive, b.exhaustive)
                self.assertEqual(a.greedy_action, b.greedy_action)
            self.assertEqual(store.records("holdout"), [])
            with self.assertRaises(ValueError):
                FPI.LabelStore(directory, {"base": "active_population", "v": 1})
            with self.assertRaises(ValueError):
                store.commit(make_episode(decisions, digest="other", episode_id="x"))


class FamilyScaleTests(unittest.TestCase):
    def test_scales_shrink_toward_the_global_scale(self):
        small = FPI.ScenarioFamily("c", 5000, 1, 0.1)
        large = FPI.ScenarioFamily("c", 25000, 5, 0.9)
        episodes = [
            make_episode([make_label([0.0, 0.2, 0.4], transition_index=i) for i in range(20)],
                         family=small, episode_id="s"),
            make_episode([make_label([0.0, 0.02, 0.04])], family=large, episode_id="l"),
        ]
        scales = FPI.family_scales(episodes, prior_strength=4.0)
        raw_small = float(np.std([0.0, 0.2, 0.4]))
        raw_large = float(np.std([0.0, 0.02, 0.04]))
        self.assertAlmostEqual(scales.scale(small.key), raw_small, delta=0.03)
        self.assertGreater(scales.scale(large.key), 3 * raw_large)  # one state: mostly prior
        self.assertEqual(scales.scale("unseen"), scales.global_scale)
        unshrunk = FPI.family_scales(episodes, prior_strength=0.0)
        self.assertAlmostEqual(unshrunk.scale(large.key), raw_large, places=12)


class RuleAndGateTests(unittest.TestCase):
    def test_lambda_zero_is_exactly_the_base_policy(self):
        prior = np.array([[1.0, 0.0, 0.5]])
        mu = np.array([[0.0, 9.0, 0.0]])
        feasible = np.ones((1, 3), bool)
        np.testing.assert_array_equal(
            FPI.rule_actions(prior, mu, 0 * mu, feasible, [2], lam=0.0, beta=1.0), [2]
        )
        self.assertEqual(int(FPI.rule_actions(prior, mu, 0 * mu, feasible, [2], lam=1.0, beta=0.0)[0]), 1)
        feasible[0, 1] = False
        self.assertEqual(int(FPI.rule_actions(prior, mu, 0 * mu, feasible, [2], lam=1.0, beta=0.0)[0]), 0)
        sigma = np.array([[0.0, 20.0, 0.0]])
        feasible[0, 1] = True
        self.assertEqual(int(FPI.rule_actions(prior, mu, sigma, feasible, [2], lam=1.0, beta=1.0)[0]), 0)

    @staticmethod
    def synthetic_holdout(episodes=24, actions=6, families=3, seed=0, harm_family=None):
        rng = np.random.default_rng(seed)
        records = []
        for e in range(episodes):
            family = FPI.ScenarioFamily("c", 5000 * (1 + e % families), 2, 0.5)
            decisions = []
            for d in range(2):
                values = rng.normal(0.0, 0.05, size=actions)
                values[0] = 0.0  # base cell
                decisions.append(make_label(values, base=0, transition_index=d, decision_index=d))
            records.append(make_episode(decisions, family=family, split="holdout", episode_id=f"h{e}"))
        scales = FPI.family_scales(records)
        states, locations = FPI.GateStates.from_episodes(records, scales)
        return records, scales, states, locations

    def predictions(self, states, name, mu):
        prior = np.zeros_like(states.values)
        prior[np.arange(states.states), states.base_actions] = 1.0
        return FPI.ModelPredictions(name, prior, mu, np.zeros_like(mu))

    def test_gate_certifies_a_model_that_is_truly_better(self):
        _, _, states, _ = self.synthetic_holdout()
        truth = np.nan_to_num(states.values) / 0.05
        result = FPI.safe_improvement_gate(
            states,
            [self.predictions(states, "champion", 0 * truth), self.predictions(states, "challenger", truth)],
            lambdas=(0.0, 0.5, 2.0, 8.0), betas=(0.0, 1.0), alpha=0.1, draws=2000,
            rng=np.random.default_rng(1), minimum_episodes=6,
        )
        self.assertEqual(result.reason, "certified_improvement")
        self.assertEqual(result.selected.model, "challenger")
        self.assertGreater(result.selected.lam, 0.0)
        self.assertGreater(result.selected.lcb, 0.0)
        self.assertLessEqual(result.selected.mean_gain, result.headroom + 1e-12)
        self.assertGreater(result.capture, 0.9)

    def test_gate_refuses_a_model_without_skill(self):
        _, _, states, _ = self.synthetic_holdout(seed=3)
        rng = np.random.default_rng(5)
        noise = rng.normal(size=states.values.shape)
        result = FPI.safe_improvement_gate(
            states, [self.predictions(states, "challenger", noise)],
            lambdas=(0.0, 0.5, 2.0, 8.0), betas=(0.0, 1.0), alpha=0.1, draws=2000,
            rng=np.random.default_rng(1), minimum_episodes=6,
        )
        # Random rankings pick cells worse than base about as often as better,
        # and the base cell value is 0 while others are N(0, 0.05): with the
        # prior pinned to base, a random model cannot be certified.
        if result.reason == "certified_improvement":
            self.assertGreater(result.selected.lcb, 0.0)
        certified_random = [c for c in result.candidates if c.certified and c.lam >= 2.0]
        self.assertEqual(certified_random, [])

    def test_gate_falls_back_without_enough_holdout_episodes(self):
        _, _, states, _ = self.synthetic_holdout(episodes=4)
        truth = np.nan_to_num(states.values)
        result = FPI.safe_improvement_gate(
            states, [self.predictions(states, "challenger", truth)],
            lambdas=(0.0, 1.0), betas=(0.0,), alpha=0.1, draws=500,
            rng=np.random.default_rng(1), minimum_episodes=6,
        )
        self.assertEqual(result.reason, "insufficient_holdout_episodes")
        self.assertEqual(result.selected.lam, 0.0)
        self.assertEqual(result.selected.model, "challenger")

    def test_gate_rejects_a_rule_that_harms_one_family(self):
        records, scales, states, _ = self.synthetic_holdout(episodes=30, families=3, seed=7)
        truth = np.nan_to_num(states.values) / 0.05
        # Invert the ranking inside family 0 only: good elsewhere, harmful there.
        harmed = states.family_index == 0
        mu = truth.copy()
        mu[harmed] = -truth[harmed]
        result = FPI.safe_improvement_gate(
            states, [self.predictions(states, "challenger", mu)],
            lambdas=(0.0, 8.0), betas=(0.0,), alpha=0.1, draws=2000,
            rng=np.random.default_rng(2), minimum_episodes=6, harm_minimum_episodes=3,
        )
        candidate = [c for c in result.candidates if c.lam == 8.0][0]
        self.assertIn(states.family_keys[0], candidate.harmful_families)
        self.assertFalse(candidate.certified)

    def test_a_single_holdout_episode_can_never_certify(self):
        _, _, states, _ = self.synthetic_holdout(episodes=1)
        truth = np.nan_to_num(states.values) / 0.05
        result = FPI.safe_improvement_gate(
            states, [self.predictions(states, "challenger", truth)],
            lambdas=(0.0, 8.0), betas=(0.0,), alpha=0.1, draws=500,
            rng=np.random.default_rng(1), minimum_episodes=1,
        )
        self.assertEqual(result.selected.lam, 0.0)
        self.assertTrue(all(np.isinf(c.lcb) and c.lcb < 0 for c in result.candidates))

    def test_gate_uses_only_exhaustive_states(self):
        partial = make_label([0.0, np.nan, 0.3], feasible=[True, True, True], exhaustive=False,
                             transition_index=1, decision_index=1)
        full = make_label([0.0, 0.1, 0.3])
        episode = make_episode([full, partial], split="holdout")
        states, locations = FPI.GateStates.from_episodes([episode], FPI.family_scales([episode]))
        self.assertEqual(states.states, 1)
        self.assertEqual(locations, [(0, 0)])


class AllocationSummaryConvergenceTests(unittest.TestCase):
    def test_branch_allocation(self):
        mask = np.ones(12, bool)
        mask[[3, 7]] = False
        rng = np.random.default_rng(0)
        self.assertEqual(
            FPI.select_fpi_branch_actions(mask, exhaustive=True, max_branches=4,
                                          must_include=(), optimism=None, rng=rng).tolist(),
            np.flatnonzero(mask).tolist(),
        )
        optimism = np.arange(12, dtype=float)
        chosen = FPI.select_fpi_branch_actions(
            mask, exhaustive=False, max_branches=6, must_include=(0, 1, 2), optimism=optimism, rng=rng
        )
        self.assertEqual(len(chosen), 6)
        self.assertTrue({0, 1, 2}.issubset(set(chosen.tolist())))
        self.assertTrue({11, 10}.issubset(set(chosen.tolist())))  # two optimistic slots of three
        self.assertFalse({3, 7} & set(chosen.tolist()))
        many = FPI.select_fpi_branch_actions(
            mask, exhaustive=False, max_branches=2, must_include=(0, 1, 2), optimism=None, rng=rng
        )
        self.assertEqual(many.tolist(), [0, 1, 2])  # must-include is never dropped

    def test_paired_gain_summary(self):
        decisions = [
            make_label([0.0, 0.2, 0.1], base=0, greedy=1, executed=2),
            make_label([0.0, np.nan, -0.1], feasible=[True, True, True], base=0, greedy=2,
                       exhaustive=False, transition_index=1, decision_index=1),
        ]
        summary = FPI.paired_gain_summary(decisions, scale=0.1)
        self.assertAlmostEqual(summary["greedy_gain"], 0.2 - 0.1)
        self.assertAlmostEqual(summary["executed_gain"], 0.1)
        self.assertAlmostEqual(summary["greedy_gain_normalized"], 1.0)
        self.assertAlmostEqual(summary["greedy_regret"], 0.0)
        self.assertAlmostEqual(summary["base_regret"], 0.2)
        self.assertEqual(summary["exhaustive_states"], 1.0)

    def test_within_state_quality(self):
        values = np.array([[0.0, 0.2, 0.1, np.nan], [0.3, 0.1, 0.2, 0.0]])
        feasible = np.array([[1, 1, 1, 0], [1, 1, 1, 1]], bool)
        quality = FPI.within_state_quality(values, values, feasible, prior=-np.nan_to_num(values))
        self.assertAlmostEqual(quality["rank_corr"], 1.0)
        self.assertAlmostEqual(quality["top1"], 1.0)
        self.assertLess(quality["prior_top1"], 1.0)

    def test_convergence(self):
        def row(i, gain, lcb, loss):
            return {"nmcc_fpi_refit_index": i, "nmcc_fpi_gate_episodes": 40,
                    "nmcc_fpi_gate_mean_gain": gain, "nmcc_fpi_gate_lcb": lcb,
                    "nmcc_fpi_deployed_lambda": 2.0, "nmcc_fpi_deployed_beta": 1.0,
                    "nmcc_fpi_refit_validation_loss": loss}
        stable = [row(i, 0.30 + 0.001 * (i % 2), 0.1, 1.0 - 0.001 * i) for i in range(10)]
        result = FPI.fpi_convergence(stable, minimum_refits=6, minimum_gate_episodes=24,
                                     window=4, gain_tolerance=0.05, validation_tolerance=0.02)
        self.assertTrue(result["converged"])
        moving = [row(i, 0.05 * i, 0.1, 1.0) for i in range(10)]
        self.assertFalse(FPI.fpi_convergence(moving, minimum_refits=6, minimum_gate_episodes=24,
                                             window=4, gain_tolerance=0.05,
                                             validation_tolerance=0.02)["converged"])
        few = FPI.fpi_convergence(stable[:3], minimum_refits=6, minimum_gate_episodes=24,
                                  window=4, gain_tolerance=0.05, validation_tolerance=0.02)
        self.assertFalse(few["converged"])


class BranchScheduleTests(unittest.TestCase):
    """Branch continuations follow the same schedule as the live bridge."""

    @staticmethod
    def build(catch_up):
        core = nmcc_testbed.build(
            grid=10, cell_x=4, cell_y=4, population=160, stop_time=31, spread_rate=(4, 2),
            casualty_rate=(40, 9), panic_rate=0.5, hazard_count=2, scenario_seed=77,
            spacing_m=150, candidate_count=10, shelter_capacity_token=40,
        )
        builder = RegionalObservationBuilder(core, initial_population=160, horizon=30, maximum_deployments=3)
        executor = RegionalShelterExecutor(core)
        clock = PI.EpisodeClock(horizon=30, interval=10, budget=3, population=160, catch_up=catch_up)
        PI.step_and_score(core, clock, PI.RewardProcessor())
        obs = builder.build(decision_index=0, simulation_time=clock.t, remaining_deployments=3)
        valuer = PI.BranchValuer(core, builder=builder, executor=executor, tapes=1)
        return core, obs, clock, valuer

    def test_full_horizon_is_the_default_and_the_grid_rule_is_unchanged(self):
        core, obs, clock, valuer = self.build(catch_up=False)
        self.assertIsNone(valuer.branch_horizon)
        values = valuer.value(obs, clock, np.flatnonzero(obs.action_mask)[:2], episode_seed=77)
        self.assertEqual(values.values.shape, (1, 2))
        self.assertEqual(valuer.steps_simulated, 3 * (30 - clock.t))

    def test_catch_up_valuation_is_reproducible_and_restores_the_episode(self):
        import CounterfactualBranch as CB
        core, obs, clock, valuer = self.build(catch_up=True)
        before = CB.live_state_digest(core)
        actions = np.flatnonzero(obs.action_mask)[:2]
        a = valuer.value(obs, clock, actions, episode_seed=77)
        b = valuer.value(obs, clock, actions, episode_seed=77)
        np.testing.assert_array_equal(a.values, b.values)
        self.assertEqual(CB.live_state_digest(core), before)

    def test_without_wait_branch_the_wait_values_are_missing(self):
        core, obs, clock, valuer = self.build(catch_up=True)
        valuer.wait_branch = False
        base = int(PI.route_saving_policy(obs))
        other = int([a for a in np.flatnonzero(obs.action_mask) if a != base][0])
        values = valuer.value(obs, clock, [base, other], episode_seed=77)
        self.assertTrue(np.all(np.isnan(values.wait_values)))
        self.assertEqual(values.base_action, base)
        label = FPI.DecisionLabel.from_state_values(
            values, feasible=obs.action_mask, transition_index=0,
            executed_action=other, greedy_action=base, exhaustive=False,
        )
        self.assertTrue(np.isfinite(label.gain(other)))
        self.assertEqual(label.gain(base), 0.0)
        self.assertTrue(np.all(np.isnan(label.natural_outcome())))

    def test_negative_branch_horizon_is_rejected(self):
        core, obs, clock, valuer = self.build(catch_up=False)
        with self.assertRaises(ValueError):
            PI.BranchValuer(core, builder=valuer.builder, executor=valuer.executor, branch_horizon=0)


if __name__ == "__main__":
    unittest.main()
