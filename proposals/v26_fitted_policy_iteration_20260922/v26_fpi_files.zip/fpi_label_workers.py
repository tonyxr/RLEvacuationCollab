#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Parallel exact-label collection for rollout-labelled fitted policy iteration.

Exact branch labels are values of the fixed base policy, so they do not
depend on the learner and can be produced by any number of processes at once.
Each worker runs complete training episodes with ``nmccFpiCollectOnly=True``:
it loads the learner's current checkpoint at the start of every episode (so
its states follow the currently deployed rule, DAgger-style, plus the same
epsilon exploration), branches exactly as the learner would, and commits the
episode to the learner's label store.  Workers never optimize and never write
the checkpoint; the learner -- an ordinary ``multicity_backtest.py`` training
run -- refits on everything committed whenever its own rollout completes.

Workers can also run *before* the learner starts, when no checkpoint exists:
they then label the states visited by the base policy under exploration,
which is the pre-training dataset the review recommended building first.

Scenario seeds come from a stream disjoint from the learner's (stream 100 +
city rank in ``multicity_backtest``), and every episode's split is a hash of
``(city, scenario seed)``, so no holdout scenario can leak into a fit split
whichever process collected it.

Example (learner in one terminal, four collectors in another)::

    python multicity_backtest.py --train-only --launch-id fpi_v26 \\
        --cities state_college_pa --train-episodes-per-city 200 \\
        --training-curriculum config/scenario_general_training_curriculum_nmcc_fpi_v26.json
    python fpi_label_workers.py --launch-id fpi_v26 --cities state_college_pa \\
        --training-curriculum config/scenario_general_training_curriculum_nmcc_fpi_v26.json \\
        --workers 4 --episodes-per-worker 25
"""

from __future__ import annotations

import argparse
import json
import multiprocessing
import os
import sys
import time

from CityProfiles import DEFAULT_CITY_PROFILE_PATH, load_city_suite
from TrainingCurriculum import build_curriculum_schedule, load_training_curriculum

LABEL_SEED_STREAM = 900  # learner training uses 100 + city scale rank


def _parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--launch-id", required=True, help="The learner's launch id")
    parser.add_argument("--launch-seed", type=int, default=20260906)
    parser.add_argument("--city-profiles", default=DEFAULT_CITY_PROFILE_PATH)
    parser.add_argument("--cities", default="all")
    parser.add_argument("--training-curriculum", required=True)
    parser.add_argument("--policy-replication", type=int, default=1)
    parser.add_argument("--workers", type=int, default=max(1, (os.cpu_count() or 2) - 1))
    parser.add_argument("--episodes-per-worker", type=int, default=8)
    parser.add_argument("--worker-offset", type=int, default=0,
                        help="Index of the first worker, to extend an earlier collection")
    parser.add_argument("--label-store", default="",
                        help="Store directory (default: next to the learner checkpoint)")
    parser.add_argument("--learning-rate", type=float, default=None,
                        help="Must equal the learner's --learning-rate (default: its default)")
    parser.add_argument("--hazard-mode", choices=("stochastic", "deterministic"),
                        default="stochastic")
    parser.add_argument("--machine", default="local")
    parser.add_argument("--override", action="append", default=[], metavar="NAME=VALUE")
    args = parser.parse_args(argv)
    if args.workers <= 0 or args.episodes_per_worker <= 0 or args.worker_offset < 0:
        parser.error("workers and episodes per worker must be positive")
    return args


def _worker_jobs(args) -> list[list[dict]]:
    """Deterministic episode specifications for every worker."""
    from multicity_backtest import (
        DEFAULT_POOLED_LEARNING_RATE,
        RUNS_ROOT,
        _city_overrides,
        _parse_overrides,
        _seed,
        _validate_shared_interface,
        balanced_rollout_episodes,
    )

    suite = load_city_suite(args.city_profiles)
    requested = None if args.cities.strip().lower() == "all" else args.cities.split(",")
    cities = suite.select(requested)
    user_overrides = _parse_overrides(args.override)
    forbidden = {"ppoRolloutEpisodes", "learningRate", "nmccFpiCollectOnly"}
    if forbidden.intersection(user_overrides):
        raise ValueError(f"These settings are fixed by the learner: {sorted(forbidden)}")
    rollout_episodes = balanced_rollout_episodes(len(cities))
    learning_rate = (
        float(DEFAULT_POOLED_LEARNING_RATE) if args.learning_rate is None else float(args.learning_rate)
    )
    overrides_by_city = {
        city.city_id: _city_overrides(suite, city, user_overrides, args.hazard_mode)
        for city in cities
    }
    for overrides in overrides_by_city.values():
        overrides["ppoRolloutEpisodes"] = rollout_episodes
        overrides["learningRate"] = learning_rate
    _validate_shared_interface(overrides_by_city)
    curriculum = load_training_curriculum(args.training_curriculum)
    schedule = build_curriculum_schedule(
        cities, curriculum, launch_seed=args.launch_seed, rollout_episodes=rollout_episodes
    )
    launch_dir = os.path.join(RUNS_ROOT, args.launch_id)
    policy_dir = os.path.join(launch_dir, "policies", f"policy_{args.policy_replication:03d}")
    checkpoint = os.path.join(policy_dir, "regional_policy.pt")
    jobs: list[list[dict]] = []
    for worker in range(args.worker_offset, args.worker_offset + args.workers):
        worker_jobs = []
        for episode in range(args.episodes_per_worker):
            global_index = worker * args.episodes_per_worker + episode
            scheduled = schedule[global_index % len(schedule)]
            city = scheduled.city
            episode_overrides = dict(overrides_by_city[city.city_id])
            episode_overrides.update(scheduled.stage_overrides)
            episode_overrides["finalizePpoRollout"] = False
            episode_overrides["nmccFpiCollectOnly"] = True
            if args.label_store:
                episode_overrides["nmccFpiLabelStore"] = os.path.abspath(args.label_store)
            worker_jobs.append(
                {
                    "worker": worker,
                    "episode": episode + 1,
                    "city_id": city.city_id,
                    "variant_id": scheduled.variant_id,
                    "stage_id": scheduled.stage_id,
                    "scenario_seed": _seed(
                        args.launch_seed, LABEL_SEED_STREAM + int(city.scale_rank), global_index
                    ),
                    "policy_seed": _seed(args.launch_seed, 10, args.policy_replication),
                    "checkpoint_path": checkpoint,
                    "diagnostics_path": os.path.join(
                        launch_dir, "label_workers", f"worker_{worker:03d}", "diagnostics.csv"
                    ),
                    "phase": os.path.join(
                        args.launch_id, "label_workers", f"worker_{worker:03d}",
                        scheduled.stage_id, scheduled.variant_id, city.city_id,
                    ),
                    "overrides": episode_overrides,
                    "machine": args.machine,
                    "log_path": os.path.join(
                        launch_dir, "label_workers", f"worker_{worker:03d}", "episodes.jsonl"
                    ),
                }
            )
        jobs.append(worker_jobs)
    return jobs


def _run_worker(jobs: list[dict]) -> dict:
    """Run one worker's episodes sequentially (in its own process)."""
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("MKL_NUM_THREADS", "1")
    import torch

    torch.set_num_threads(1)
    from backtest import _run_episode

    completed, failed = 0, 0
    for job in jobs:
        os.makedirs(os.path.dirname(job["log_path"]), exist_ok=True)
        started = time.time()
        record = {key: job[key] for key in ("worker", "episode", "city_id", "variant_id",
                                             "stage_id", "scenario_seed")}
        try:
            row = _run_episode(
                replication=int(job["episode"]),
                machine=job["machine"],
                phase=job["phase"],
                strategy="rl",
                train_mode=True,
                scenario_seed=int(job["scenario_seed"]),
                policy_seed=int(job["policy_seed"]),
                checkpoint_path=job["checkpoint_path"],
                diagnostics_path=job["diagnostics_path"],
                overrides=job["overrides"],
            )
            record.update(
                {
                    "status": "committed",
                    "labelled_states": row.get("nmcc_fpi_episode_labelled_states"),
                    "holdout": row.get("nmcc_fpi_episode_holdout"),
                    "greedy_gain": row.get("nmcc_fpi_episode_greedy_gain"),
                    "deployed_lambda": row.get("nmcc_fpi_deployed_lambda"),
                    "episode_return": row.get("episode_return"),
                }
            )
            completed += 1
        except Exception as exc:  # a failed episode is logged, never silently replaced
            record.update({"status": "failed", "error": repr(exc)})
            failed += 1
        record["wall_seconds"] = time.time() - started
        with open(job["log_path"], "a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, default=str) + "\n")
    return {"completed": completed, "failed": failed}


def main(argv=None) -> int:
    args = _parse_args(argv)
    jobs = _worker_jobs(args)
    context = multiprocessing.get_context("spawn")
    with context.Pool(processes=len(jobs)) as pool:
        results = pool.map(_run_worker, jobs)
    summary = {
        "workers": len(jobs),
        "episodes_committed": sum(item["completed"] for item in results),
        "episodes_failed": sum(item["failed"] for item in results),
    }
    print(json.dumps(summary, indent=2))
    return 0 if summary["episodes_failed"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
