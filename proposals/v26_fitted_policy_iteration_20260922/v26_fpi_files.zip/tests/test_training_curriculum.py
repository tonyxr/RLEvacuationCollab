import json
import tempfile
import unittest
from pathlib import Path

from CityProfiles import load_city_suite
from TrainingCurriculum import (
    DEFAULT_TRAINING_CURRICULUM_PATH,
    build_curriculum_schedule,
    load_training_curriculum,
)
from multicity_backtest import balanced_rollout_episodes


ROOT = Path(__file__).resolve().parents[1]


class TrainingCurriculumTests(unittest.TestCase):
    def test_registered_curriculum_matches_confirmatory_budget(self):
        curriculum = load_training_curriculum(DEFAULT_TRAINING_CURRICULUM_PATH)
        self.assertEqual(curriculum.episodes_per_city, 120)
        self.assertEqual(curriculum.stages[-1].episodes_per_city, 84)

    def test_operational_curriculum_reaches_target_scale_with_declared_cohorts(self):
        curriculum = load_training_curriculum(
            ROOT / "config" / "staged_training_curriculum_operational.json"
        )
        self.assertEqual(curriculum.episodes_per_city, 20)
        self.assertEqual(curriculum.episodes_per_city * 5, 100)
        self.assertEqual(curriculum.stages[-1].episodes_per_city, 6)
        expected_sizes = [10, 20, 20, 20, 20, 20]
        self.assertEqual(
            [stage.variants[0].overrides["pedestrianGroupSize"] for stage in curriculum.stages],
            expected_sizes,
        )
        self.assertEqual(
            curriculum.stages[-1].variants[0].overrides["pedVol"],
            50000,
        )

    def test_nmcc_curriculum_is_a_complete_fixed_learner_contract(self):
        curriculum = load_training_curriculum(
            ROOT
            / "config"
            / "state_college_training_curriculum_3000_nmcc_hybrid.json"
        )
        self.assertEqual(curriculum.episodes_per_city, 64)
        overrides = curriculum.stages[0].variants[0].overrides
        self.assertTrue(overrides["nmccEnabled"])
        self.assertEqual(overrides["nmccCounterfactualHorizon"], 10)
        self.assertEqual(overrides["nmccEnsembleSize"], 3)
        self.assertEqual(overrides["maxAdditionalShelters"], 5)
        self.assertEqual(overrides["shelterCapacityToken"], 500)
        self.assertGreater(overrides["actionTemperatureStart"], 1.0)

    def test_2500_nmcc_curriculum_has_four_rollout_aligned_learning_stages(self):
        curriculum = load_training_curriculum(
            ROOT
            / "config"
            / "state_college_training_curriculum_2500_nmcc_staged_v22.json"
        )
        self.assertEqual(curriculum.episodes_per_city, 64)
        self.assertEqual(
            [stage.episodes_per_city for stage in curriculum.stages],
            [8, 8, 16, 32],
        )
        self.assertEqual(
            [stage.stage_id for stage in curriculum.stages],
            ["N0", "N1", "N2", "N3"],
        )
        first = curriculum.stages[0].variants[0].overrides
        self.assertEqual(first["pedVol"], 2500)
        self.assertEqual(first["nmccNaturalPretrainRollouts"], 1)
        self.assertEqual(first["nmccCausalPretrainRollouts"], 1)
        self.assertEqual(first["nmccControllerWarmupRollouts"], 2)
        self.assertAlmostEqual(first["nmccJointCounterfactualWeight"], 0.35)

    def test_v24_nmcc_pi_curriculum_trains_the_actor_on_exact_branch_targets(self):
        from NMCCPIConfig import NMCC_PI_CORE_FIELDS, NMCC_V26_ATTRIBUTES

        curriculum = load_training_curriculum(
            ROOT / "config" / "state_college_training_curriculum_2500_nmcc_pi_v24.json"
        )
        self.assertEqual(curriculum.episodes_per_city, 64)
        overrides = curriculum.stages[0].variants[0].overrides
        self.assertTrue(overrides["nmccPolicyImprovement"])
        self.assertEqual(overrides["actorPrior"], "route_time_saving")
        self.assertEqual(overrides["representationMode"], "shared_phasic")
        self.assertEqual(overrides["nmccGuidanceMaximum"], 0.0)
        self.assertEqual(overrides["actionTemperatureStart"], 1.0)
        for key in (
            "nmccNaturalPretrainRollouts",
            "nmccCausalPretrainRollouts",
            "nmccControllerWarmupRollouts",
        ):
            self.assertEqual(overrides[key], 0)
        for attribute, _, kind, _ in NMCC_PI_CORE_FIELDS:
            if attribute in NMCC_V26_ATTRIBUTES:
                continue  # v26 rows postdate this curriculum; defaults reproduce v24
            self.assertIn(attribute, overrides)
            self.assertIsInstance(overrides[attribute], (int, float) if kind is float else kind)

    def test_v26_curricula_declare_the_complete_fitted_policy_iteration_contract(self):
        from NMCCPIConfig import NMCC_FPI_PROCESS_ATTRIBUTES, NMCC_PI_CORE_FIELDS

        for name, variants in (
            ("scenario_general_training_curriculum_nmcc_fpi_v26.json", 25),
            ("state_college_training_curriculum_nmcc_fpi_v26_pilot.json", 9),
        ):
            curriculum = load_training_curriculum(ROOT / "config" / name)
            stage = curriculum.stages[0]
            self.assertEqual(len(stage.variants), variants)
            overrides = stage.variants[0].overrides
            for attribute, _, kind, _ in NMCC_PI_CORE_FIELDS:
                if attribute in NMCC_FPI_PROCESS_ATTRIBUTES:
                    self.assertNotIn(attribute, overrides)
                    continue
                self.assertIn(attribute, overrides)
                self.assertIsInstance(
                    overrides[attribute], (int, float) if kind is float else kind
                )
            self.assertEqual(overrides["nmccPiActorObjective"], "fitted_value")
            self.assertEqual(overrides["nmccPiBranchHorizon"], 0)
            self.assertTrue(overrides["shelterDecisionCatchUp"])
            self.assertTrue(overrides["scenarioDescriptors"])
            # Strength-2 orthogonal array: every pair of scenario-factor levels
            # appears equally often.
            import collections
            import itertools

            rows = [variant.overrides for variant in stage.variants]
            for first, second in itertools.combinations(("pedVol", "hazardVol", "panicRate"), 2):
                counts = collections.Counter((row[first], row[second]) for row in rows)
                self.assertEqual(len(set(counts.values())), 1)
            self.assertEqual(
                curriculum.learner_overrides,
                {
                    key: value
                    for key, value in overrides.items()
                    if key not in {"pedVol", "hazardVol", "panicRate"}
                    and key in curriculum.learner_overrides
                },
            )
            scenarios = curriculum.evaluation_scenarios()
            self.assertEqual(len(scenarios), variants)
            self.assertIn("pedVol", scenarios[0][1])
            self.assertNotIn("nmccPiActorObjective", scenarios[0][1])

    def test_v25_curriculum_stages_system_learning_before_score_control(self):
        curriculum = load_training_curriculum(
            ROOT
            / "config"
            / "state_college_training_curriculum_2500_nmcc_score_v25.json"
        )
        overrides = curriculum.stages[0].variants[0].overrides
        self.assertEqual(overrides["pedVol"], 2500)
        self.assertEqual(overrides["nmccPiActorObjective"], "score_ranking")
        self.assertGreater(overrides["nmccNaturalPretrainRollouts"], 0)
        self.assertGreater(overrides["nmccCausalPretrainRollouts"], 0)
        self.assertGreater(overrides["nmccControllerWarmupRollouts"], 0)
        self.assertTrue(overrides["requireCandidateOperationalBenefit"])
        self.assertGreater(overrides["explorationRateStart"], overrides["explorationRateEnd"])
        self.assertEqual(overrides["learningRateSchedule"], "cosine")

    def test_v23_temporal_credit_curriculum_decouples_actor_and_nmcc_auxiliary(self):
        curriculum = load_training_curriculum(
            ROOT
            / "config"
            / "state_college_training_curriculum_2500_temporal_credit_v23.json"
        )
        self.assertEqual(curriculum.episodes_per_city, 64)
        self.assertEqual(
            [stage.episodes_per_city for stage in curriculum.stages],
            [8, 8, 16, 32],
        )
        first = curriculum.stages[0].variants[0].overrides
        self.assertEqual(first["nmccCounterfactualWeight"], 0.0)
        self.assertEqual(first["nmccJointCounterfactualWeight"], 0.0)
        self.assertEqual(first["nmccGuidanceMaximum"], 0.0)
        self.assertEqual(first["nmccTeacherCoefficient"], 0.0)
        self.assertEqual(first["actorLearningRate"], 1e-4)
        self.assertEqual(first["criticLearningRate"], 3e-4)
        self.assertEqual(first["actorPpoEpochs"], 1)
        self.assertEqual(first["criticPpoEpochs"], 4)

    def test_schedule_is_reproducible_city_balanced_and_rollout_complete(self):
        cities = load_city_suite().cities
        curriculum = load_training_curriculum(DEFAULT_TRAINING_CURRICULUM_PATH)
        rollout = balanced_rollout_episodes(len(cities))
        first = build_curriculum_schedule(
            cities,
            curriculum,
            launch_seed=91,
            rollout_episodes=rollout,
        )
        second = build_curriculum_schedule(
            cities,
            curriculum,
            launch_seed=91,
            rollout_episodes=rollout,
        )
        self.assertEqual(first, second)
        self.assertEqual(len(first), 600)
        for start in range(0, len(first), rollout):
            block = first[start : start + rollout]
            for city in cities:
                self.assertEqual(
                    sum(item.city.city_id == city.city_id for item in block),
                    2,
                )
            self.assertEqual(len({item.stage_id for item in block}), 1)

    def test_factor_randomization_stage_realizes_exact_variant_weights_per_city(self):
        cities = load_city_suite().cities
        curriculum = load_training_curriculum(DEFAULT_TRAINING_CURRICULUM_PATH)
        schedule = build_curriculum_schedule(
            cities,
            curriculum,
            launch_seed=19,
            rollout_episodes=10,
        )
        robust = [item for item in schedule if item.stage_id == "S4"]
        for city in cities:
            variants = [
                item.variant_id
                for item in robust
                if item.city.city_id == city.city_id
            ]
            self.assertEqual(variants.count("small_high_disruption"), 4)
            self.assertEqual(variants.count("low_medium_high"), 4)
            self.assertEqual(variants.count("center"), 4)
            self.assertEqual(variants.count("high_medium_low"), 4)
            self.assertEqual(variants.count("large_low_disruption"), 4)

    def test_protected_stage_override_is_rejected(self):
        payload = {
            "schema_version": 1,
            "curriculum_id": "invalid",
            "description": "invalid protected change",
            "stages": [
                {
                    "stage_id": "bad",
                    "label": "bad",
                    "episodes_per_city": 2,
                    "variants": [
                        {
                            "variant_id": "bad",
                            "weight": 1,
                            "overrides": {"pedVol": 10, "cellX": 4},
                        }
                    ],
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "curriculum.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "protected"):
                load_training_curriculum(path)

    def test_learner_overrides_cannot_change_between_variants(self):
        payload = {
            "schema_version": 1,
            "curriculum_id": "invalid-learner-drift",
            "description": "learner settings must be fixed",
            "stages": [
                {
                    "stage_id": "bad",
                    "label": "bad",
                    "episodes_per_city": 2,
                    "variants": [
                        {
                            "variant_id": "a",
                            "weight": 1,
                            "overrides": {
                                "pedVol": 10,
                                "nmccEnabled": True,
                            },
                        },
                        {
                            "variant_id": "b",
                            "weight": 1,
                            "overrides": {
                                "pedVol": 10,
                                "nmccEnabled": False,
                            },
                        },
                    ],
                }
            ],
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "curriculum.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "identical"):
                load_training_curriculum(path)


if __name__ == "__main__":
    unittest.main()
