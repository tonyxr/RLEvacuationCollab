#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Rollout-labelled fitted policy iteration for sequential shelter deployment.

This is the torch-free core of the model-version-26 learner (NMCC-FPI).  It
replaces the per-rollout actor fit of v24/v25 with the estimator the problem
actually admits once NMCC exact branching is available: approximate policy
iteration by regression on a persistent set of exact, common-random-number
paired rollout labels, with a safe-policy-improvement gate between the fitted
model and the executed decision rule.

Why the actor-fitting design could not generalize
-------------------------------------------------
An exact branch label at a decision state ``s`` is the return-to-go

    Q_b(s, c) = E[ sum of rewards from s | install c now, then follow b ]

under a *fixed* base policy ``b`` (route saving).  It does not depend on the
learner, so it stays valid forever; only which states are visited depends on
the executed policy.  v25 used each label for one trust-region step and threw
it away, so every update learned from about 19 states and the actor memorized
them (out-of-sample top-1 0.41 versus 0.40 for the untrained prior).  The
labels also stopped 20 steps after the first decision, before most of the
return arrives, and covered 6 of about 18 cells.

What this module implements
---------------------------
1. **Label store** (:class:`LabelStore`).  Every labelled episode is written
   once, atomically, as three files: frames (torch, written by the caller),
   labels (``.npz``) and a JSON commit record.  A store is bound to a *label
   contract* (base policy, reward, decision schedule, masks, feature schema):
   labels produced under a different contract are never mixed in.  Collection
   can run in many processes at once; the learner reads whatever is committed.
2. **Episode-level splits** (:func:`assign_split`).  A deterministic hash of
   ``(city, scenario seed)`` puts every episode in ``fit``, ``validation``
   (early stopping) or ``holdout`` (the improvement gate).  Holdout episodes
   are branched exhaustively at every decision so that *any* candidate
   decision rule can be evaluated exactly on them.
3. **Scenario-family normalization** (:func:`family_scales`).  The value of
   one shelter scales with capacity per person and with hazard severity, so a
   pooled squared error across 5 000 and 25 000 pedestrians would weight the
   small scenarios about 25 times more.  Within-state contrasts are divided by
   a shrunken per-family scale; the gate weights families equally.
4. **Decision rule** (:func:`rule_actions`).  ``b(s)`` when ``lambda = 0``;
   otherwise ``argmax_c prior(s, c) + lambda * (mu(s, c) - beta * sigma(s, c))``
   with ``mu, sigma`` the ensemble mean and disagreement of the fitted
   within-state value.  ``lambda`` trades the base policy against the model;
   ``beta`` is the pessimism of a lower confidence bound.
5. **Safe-policy-improvement gate** (:func:`safe_improvement_gate`).  By the
   performance-difference lemma, ``J(pi) - J(b) = E_{s ~ d_pi} sum_k
   [Q_b(s_k, pi(s_k)) - Q_b(s_k, b(s_k))]``.  Every term is observed exactly
   on an exhaustively branched holdout state, so the gate scores every
   candidate ``(model, lambda, beta)`` by the per-episode sum of these
   exact paired advantages, averages episodes within a scenario family and
   families with equal weight, and certifies a candidate only if its lower
   bound -- the more conservative of an episode-cluster bootstrap and a
   cluster-robust t bound, Bonferroni-corrected over candidates -- is
   positive and no family is significantly harmed.  Otherwise the base
   policy acts.  Holdout episodes run the deployed rule without exploration,
   so their states come from the deployed rule's own distribution.  The
   first decision's state does not depend on the policy at all, so its term
   is exact for every candidate (reported as ``first_decision_gain``); for
   later decisions the score is the conservative-policy-iteration surrogate
   ``E_{s ~ d_deployed}[A_b(s, pi(s))]``, whose error is bounded by the shift
   in the later-decision state distribution times the (small) later-decision
   headroom.  The claim of improvement is then confirmed by paired held-out
   evaluation episodes against the ``route_saving`` strategy.
6. **Branch allocation** (:func:`select_fpi_branch_actions`).  Exhaustive at
   the first decisions (where the value is) and on holdout episodes; later
   decisions always include the base, executed and greedy cells, then
   optimistic ``mu + kappa * sigma`` cells, then uniform random support.
7. **Paired learning curve** (:func:`paired_gain_summary`) and a convergence
   criterion for fitted policy iteration (:func:`fpi_convergence`).

The torch side (network refit and batched recurrent replay) lives in
``RLBridge``; everything here is numpy and is tested without torch.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import math
import os
import time
from typing import Iterable, Mapping, Optional, Sequence

import numpy as np

from DecisionInterface import SCENARIO_FEATURE_NAMES, scenario_descriptor  # noqa: F401

LABEL_SCHEMA_VERSION = 1
SPLITS = ("fit", "validation", "holdout")
REFIT_MODES = ("scratch", "warm")

OUTCOME_DIMENSION = 6


# -----------------------------------------------------------------------------
# Scenario families (descriptors live in DecisionInterface, the observation
# schema owner, and are re-exported here)
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class ScenarioFamily:
    """One cell of the scenario design: city x pedestrians x hazards x panic."""

    city_id: str
    population: int
    hazards: int
    panic_rate: float

    @property
    def key(self) -> str:
        return (
            f"{self.city_id}|P={int(self.population)}|H={int(self.hazards)}"
            f"|K={float(self.panic_rate):.4g}"
        )

    def as_dict(self) -> dict:
        return {
            "city_id": str(self.city_id),
            "population": int(self.population),
            "hazards": int(self.hazards),
            "panic_rate": float(self.panic_rate),
        }

    @classmethod
    def from_dict(cls, payload: Mapping) -> "ScenarioFamily":
        return cls(
            city_id=str(payload["city_id"]),
            population=int(payload["population"]),
            hazards=int(payload["hazards"]),
            panic_rate=float(payload["panic_rate"]),
        )


def assign_split(
    city_id: str,
    scenario_seed: int,
    *,
    holdout_fraction: float,
    validation_fraction: float,
    salt: str = "nmcc-fpi-v1",
) -> str:
    """Deterministic episode-level split from ``(city, scenario seed)``.

    The same scenario always lands in the same split, whichever process
    collected it, so parallel collectors cannot leak a holdout scenario into
    the fit set.
    """
    holdout_fraction = float(holdout_fraction)
    validation_fraction = float(validation_fraction)
    if not 0.0 <= holdout_fraction < 1.0 or not 0.0 <= validation_fraction < 1.0:
        raise ValueError("split fractions must lie in [0, 1)")
    if holdout_fraction + validation_fraction >= 1.0:
        raise ValueError("holdout and validation fractions must leave a fit split")
    digest = hashlib.sha256(
        f"{salt}|{str(city_id)}|{int(scenario_seed)}".encode("utf-8")
    ).digest()
    u = int.from_bytes(digest[:8], "big") / float(2**64)
    if u < holdout_fraction:
        return "holdout"
    if u < holdout_fraction + validation_fraction:
        return "validation"
    return "fit"


def bootstrap_weights(episode_id: str, decision_index: int, members: int) -> np.ndarray:
    """Poisson(1) ensemble weights that are a fixed function of the state.

    A state keeps its weights across refits, so which members see it is
    stable while the dataset grows.
    """
    seed = int.from_bytes(
        hashlib.sha256(f"{episode_id}|{int(decision_index)}|boot".encode("utf-8")).digest()[:8],
        "big",
    )
    weights = np.random.default_rng(seed).poisson(1.0, size=int(members)).astype(np.float64)
    if weights.sum() <= 0.0:
        # Probability exp(-M): keep the label in one member rather than
        # discarding an exact label outright.
        weights[seed % int(members)] = 1.0
    return weights


def parse_grid(text: str, *, name: str, minimum: float = 0.0) -> tuple[float, ...]:
    """Parse a comma-separated, strictly increasing grid of finite values."""
    values = tuple(float(item) for item in str(text).split(",") if item.strip())
    if not values:
        raise ValueError(f"{name} must contain at least one value")
    if any(not math.isfinite(value) or value < minimum for value in values):
        raise ValueError(f"{name} values must be finite and >= {minimum}")
    if any(b <= a for a, b in zip(values, values[1:])):
        raise ValueError(f"{name} must be strictly increasing")
    return values


# -----------------------------------------------------------------------------
# Label contract
# -----------------------------------------------------------------------------


def canonical_json(payload) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)


def contract_digest(contract: Mapping) -> str:
    return hashlib.sha256(canonical_json(dict(contract)).encode("utf-8")).hexdigest()


# -----------------------------------------------------------------------------
# Labels
# -----------------------------------------------------------------------------


@dataclass
class DecisionLabel:
    """Exact paired branch values at one decision state.

    ``values[t, c]`` is the return-to-go on tape ``t`` after installing cell
    ``c`` and continuing with the base policy; it is ``NaN`` for cells that
    were not branched.  ``wait_values`` is the WAIT branch (``NaN`` if it was
    not run).  ``outcomes``/``wait_outcomes`` are the six normalized physical
    outcomes of the same branches.
    """

    transition_index: int
    decision_index: int
    simulation_time: int
    feasible: np.ndarray  # (A,) bool
    values: np.ndarray  # (T, A) float64, NaN where unbranched
    wait_values: np.ndarray  # (T,) float64
    outcomes: np.ndarray  # (T, A, 6) float32, NaN where unbranched
    wait_outcomes: np.ndarray  # (T, 6) float32
    base_action: int
    executed_action: int
    greedy_action: int
    exhaustive: bool

    def __post_init__(self) -> None:
        self.feasible = np.asarray(self.feasible, dtype=bool).reshape(-1)
        actions = self.feasible.size
        self.values = np.asarray(self.values, dtype=np.float64)
        if self.values.ndim != 2 or self.values.shape[1] != actions:
            raise ValueError("values must have shape (tapes, actions)")
        tapes = self.values.shape[0]
        if tapes <= 0:
            raise ValueError("at least one tape is required")
        self.wait_values = np.asarray(self.wait_values, dtype=np.float64).reshape(tapes)
        self.outcomes = np.asarray(self.outcomes, dtype=np.float32).reshape(
            tapes, actions, OUTCOME_DIMENSION
        )
        self.wait_outcomes = np.asarray(self.wait_outcomes, dtype=np.float32).reshape(
            tapes, OUTCOME_DIMENSION
        )
        branched = np.isfinite(self.values)
        if not np.array_equal(branched, np.broadcast_to(branched[0], branched.shape)):
            raise ValueError("every tape must branch the same cells")
        if np.any(branched[0] & ~self.feasible):
            raise ValueError("a branched cell is infeasible")
        for name in ("base_action", "executed_action", "greedy_action"):
            action = int(getattr(self, name))
            if not 0 <= action < actions or not bool(branched[0, action]):
                raise ValueError(f"{name} {action} must be a branched cell")
            setattr(self, name, action)
        if self.exhaustive and not np.array_equal(branched[0], self.feasible):
            raise ValueError("an exhaustive state must branch every feasible cell")
        self.exhaustive = bool(self.exhaustive)
        self.transition_index = int(self.transition_index)
        self.decision_index = int(self.decision_index)
        self.simulation_time = int(self.simulation_time)

    @property
    def tapes(self) -> int:
        return int(self.values.shape[0])

    @property
    def num_actions(self) -> int:
        return int(self.feasible.size)

    @property
    def branched(self) -> np.ndarray:
        return np.isfinite(self.values[0])

    @property
    def branched_count(self) -> int:
        return int(self.branched.sum())

    def mean_values(self) -> np.ndarray:
        """Tape-mean value per cell, ``NaN`` where unbranched."""
        return self.values.mean(axis=0)

    def advantage_vs_base(self) -> np.ndarray:
        """``Q(s, c) - Q(s, b(s))``, paired within each tape, then averaged."""
        return (self.values - self.values[:, [self.base_action]]).mean(axis=0)

    def contrast_standard_error(self) -> np.ndarray:
        """Tape standard error of each cell's contrast with the base cell."""
        if self.tapes < 2:
            return np.full(self.num_actions, np.nan)
        contrast = self.values - self.values[:, [self.base_action]]
        return contrast.std(axis=0, ddof=1) / math.sqrt(self.tapes)

    @property
    def best_action(self) -> int:
        return int(np.nanargmax(self.mean_values()))

    def within_state_variance(self) -> float:
        values = self.mean_values()[self.branched]
        return float(np.var(values)) if values.size >= 2 else float("nan")

    def gain(self, action: int) -> float:
        """Exact paired gain of ``action`` over the base action (NaN if unbranched)."""
        return float(self.advantage_vs_base()[int(action)])

    def natural_outcome(self) -> np.ndarray:
        return self.wait_outcomes.mean(axis=0)

    def outcome_effects(self) -> np.ndarray:
        """Candidate-caused physical change relative to WAIT, ``NaN`` if unavailable."""
        return (self.outcomes - self.wait_outcomes[:, None, :]).mean(axis=0)

    @classmethod
    def from_state_values(
        cls,
        state_values,
        *,
        feasible: np.ndarray,
        transition_index: int,
        executed_action: int,
        greedy_action: int,
        exhaustive: bool,
    ) -> "DecisionLabel":
        """Build a label from ``NMCCPolicyImprovement.StateValues``."""
        feasible = np.asarray(feasible, dtype=bool).reshape(-1)
        actions = np.asarray(state_values.actions, dtype=np.int64)
        tapes = int(state_values.values.shape[0])
        values = np.full((tapes, feasible.size), np.nan, dtype=np.float64)
        values[:, actions] = np.asarray(state_values.values, dtype=np.float64)
        outcomes = np.full(
            (tapes, feasible.size, OUTCOME_DIMENSION), np.nan, dtype=np.float32
        )
        outcomes[:, actions] = np.asarray(state_values.outcomes, dtype=np.float32)
        return cls(
            transition_index=int(transition_index),
            decision_index=int(state_values.decision_index),
            simulation_time=int(state_values.simulation_time),
            feasible=feasible,
            values=values,
            wait_values=np.asarray(state_values.wait_values, dtype=np.float64),
            outcomes=outcomes,
            wait_outcomes=np.asarray(state_values.wait_outcomes, dtype=np.float32),
            base_action=int(state_values.base_action),
            executed_action=int(executed_action),
            greedy_action=int(greedy_action),
            exhaustive=bool(exhaustive),
        )


@dataclass
class EpisodeLabels:
    """All labelled decisions of one episode plus its provenance."""

    episode_id: str
    family: ScenarioFamily
    split: str
    contract_digest: str
    scenario_seed: int
    policy_seed: int
    decisions: list[DecisionLabel]
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.split not in SPLITS:
            raise ValueError(f"split must be one of {SPLITS}")
        if not self.decisions:
            raise ValueError("an episode record needs at least one labelled decision")
        sizes = {decision.num_actions for decision in self.decisions}
        tapes = {decision.tapes for decision in self.decisions}
        if len(sizes) != 1 or len(tapes) != 1:
            raise ValueError("decisions of one episode must share actions and tapes")
        indices = [decision.transition_index for decision in self.decisions]
        if indices != sorted(set(indices)):
            raise ValueError("decision transition indices must be strictly increasing")

    @property
    def num_actions(self) -> int:
        return self.decisions[0].num_actions

    @property
    def tapes(self) -> int:
        return self.decisions[0].tapes

    def arrays(self) -> dict[str, np.ndarray]:
        stack = np.stack
        return {
            "transition_index": np.asarray([d.transition_index for d in self.decisions], np.int64),
            "decision_index": np.asarray([d.decision_index for d in self.decisions], np.int64),
            "simulation_time": np.asarray([d.simulation_time for d in self.decisions], np.int64),
            "feasible": stack([d.feasible for d in self.decisions]),
            "values": stack([d.values for d in self.decisions]),
            "wait_values": stack([d.wait_values for d in self.decisions]),
            "outcomes": stack([d.outcomes for d in self.decisions]),
            "wait_outcomes": stack([d.wait_outcomes for d in self.decisions]),
            "base_action": np.asarray([d.base_action for d in self.decisions], np.int64),
            "executed_action": np.asarray([d.executed_action for d in self.decisions], np.int64),
            "greedy_action": np.asarray([d.greedy_action for d in self.decisions], np.int64),
            "exhaustive": np.asarray([d.exhaustive for d in self.decisions], bool),
        }

    @staticmethod
    def decisions_from_arrays(arrays: Mapping[str, np.ndarray]) -> list[DecisionLabel]:
        count = int(np.asarray(arrays["transition_index"]).size)
        return [
            DecisionLabel(
                transition_index=int(arrays["transition_index"][i]),
                decision_index=int(arrays["decision_index"][i]),
                simulation_time=int(arrays["simulation_time"][i]),
                feasible=arrays["feasible"][i],
                values=arrays["values"][i],
                wait_values=arrays["wait_values"][i],
                outcomes=arrays["outcomes"][i],
                wait_outcomes=arrays["wait_outcomes"][i],
                base_action=int(arrays["base_action"][i]),
                executed_action=int(arrays["executed_action"][i]),
                greedy_action=int(arrays["greedy_action"][i]),
                exhaustive=bool(arrays["exhaustive"][i]),
            )
            for i in range(count)
        ]

    def record(self) -> dict:
        return {
            "schema_version": LABEL_SCHEMA_VERSION,
            "episode_id": self.episode_id,
            "family": self.family.as_dict(),
            "family_key": self.family.key,
            "split": self.split,
            "contract_digest": self.contract_digest,
            "scenario_seed": int(self.scenario_seed),
            "policy_seed": int(self.policy_seed),
            "decisions": len(self.decisions),
            "num_actions": self.num_actions,
            "tapes": self.tapes,
            "exhaustive_decisions": int(sum(d.exhaustive for d in self.decisions)),
            "metadata": dict(self.metadata),
        }


def new_episode_id(*parts) -> str:
    """Globally unique episode id (content plus a nanosecond clock and pid)."""
    material = "|".join(str(part) for part in parts)
    material += f"|{time.time_ns()}|{os.getpid()}"
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:24]


def _atomic_write_bytes(path: str, payload: bytes) -> None:
    temporary = f"{path}.tmp.{os.getpid()}"
    try:
        with open(temporary, "wb") as handle:
            handle.write(payload)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.remove(temporary)


class LabelStore:
    """Directory of committed label shards bound to one label contract.

    Layout, per episode ``<id>``: ``<id>.frames.pt`` (observation history,
    written by the caller), ``<id>.labels.npz`` and ``<id>.json``.  The JSON
    record is written last and is the commit marker: a reader never sees a
    partial episode.  ``store_contract.json`` fixes the contract the first
    time the store is used; a process with a different contract is refused.
    """

    CONTRACT_FILE = "store_contract.json"
    _record_cache: dict[str, tuple[float, dict]] = {}
    _label_cache: dict[str, tuple[float, list[DecisionLabel]]] = {}

    def __init__(self, directory: str, contract: Mapping):
        self.directory = os.path.abspath(str(directory))
        os.makedirs(self.directory, exist_ok=True)
        self.contract = dict(contract)
        self.digest = contract_digest(self.contract)
        path = os.path.join(self.directory, self.CONTRACT_FILE)
        if os.path.exists(path):
            with open(path, "r", encoding="utf-8") as handle:
                existing = json.load(handle)
            if existing.get("digest") != self.digest:
                raise ValueError(
                    f"Label store {self.directory} was created under a different label "
                    "contract; exact labels from another base policy, reward, schedule "
                    "or feature schema cannot be mixed. Use a new store directory."
                )
        else:
            payload = {"digest": self.digest, "contract": self.contract,
                       "schema_version": LABEL_SCHEMA_VERSION}
            try:
                # Exclusive create: concurrent first writers agree or fail loudly.
                with open(path, "x", encoding="utf-8") as handle:
                    json.dump(payload, handle, indent=2, sort_keys=True, default=str)
            except FileExistsError:
                with open(path, "r", encoding="utf-8") as handle:
                    existing = json.load(handle)
                if existing.get("digest") != self.digest:
                    raise ValueError("Concurrent label-store creation with a different contract")

    # -- paths ----------------------------------------------------------------

    def frames_path(self, episode_id: str) -> str:
        return os.path.join(self.directory, f"{episode_id}.frames.pt")

    def labels_path(self, episode_id: str) -> str:
        return os.path.join(self.directory, f"{episode_id}.labels.npz")

    def record_path(self, episode_id: str) -> str:
        return os.path.join(self.directory, f"{episode_id}.json")

    # -- writing --------------------------------------------------------------

    def commit(self, episode: EpisodeLabels) -> str:
        """Write labels and the commit record; frames must already exist."""
        if episode.contract_digest != self.digest:
            raise ValueError("episode labels were produced under another contract")
        if not os.path.exists(self.frames_path(episode.episode_id)):
            raise FileNotFoundError("write the episode frames before committing its labels")
        if os.path.exists(self.record_path(episode.episode_id)):
            raise FileExistsError(f"episode {episode.episode_id} is already committed")
        import io

        buffer = io.BytesIO()
        np.savez_compressed(buffer, **episode.arrays())
        _atomic_write_bytes(self.labels_path(episode.episode_id), buffer.getvalue())
        record = episode.record()
        record["committed_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        _atomic_write_bytes(
            self.record_path(episode.episode_id),
            json.dumps(record, indent=2, sort_keys=True, default=str).encode("utf-8"),
        )
        return episode.episode_id

    # -- reading --------------------------------------------------------------

    def records(self, split: Optional[str] = None) -> list[dict]:
        """Committed, contract-matching episode records, oldest first."""
        output = []
        for name in sorted(os.listdir(self.directory)):
            if not name.endswith(".json") or name == self.CONTRACT_FILE:
                continue
            path = os.path.join(self.directory, name)
            try:
                mtime = os.path.getmtime(path)
            except OSError:
                continue
            cached = self._record_cache.get(path)
            if cached is None or cached[0] != mtime:
                try:
                    with open(path, "r", encoding="utf-8") as handle:
                        record = json.load(handle)
                except (OSError, ValueError):
                    continue
                self._record_cache[path] = (mtime, record)
            else:
                record = cached[1]
            if record.get("contract_digest") != self.digest:
                continue
            episode_id = str(record.get("episode_id", ""))
            if not (
                os.path.exists(self.labels_path(episode_id))
                and os.path.exists(self.frames_path(episode_id))
            ):
                continue
            if split is not None and record.get("split") != split:
                continue
            output.append(record)
        output.sort(key=lambda item: (str(item.get("committed_utc", "")), str(item["episode_id"])))
        return output

    def load(self, record: Mapping) -> EpisodeLabels:
        episode_id = str(record["episode_id"])
        path = self.labels_path(episode_id)
        mtime = os.path.getmtime(path)
        cached = self._label_cache.get(path)
        if cached is None or cached[0] != mtime:
            with np.load(path, allow_pickle=False) as arrays:
                decisions = EpisodeLabels.decisions_from_arrays(
                    {key: arrays[key] for key in arrays.files}
                )
            self._label_cache[path] = (mtime, decisions)
        else:
            decisions = cached[1]
        return EpisodeLabels(
            episode_id=episode_id,
            family=ScenarioFamily.from_dict(record["family"]),
            split=str(record["split"]),
            contract_digest=str(record["contract_digest"]),
            scenario_seed=int(record["scenario_seed"]),
            policy_seed=int(record["policy_seed"]),
            decisions=list(decisions),
            metadata=dict(record.get("metadata", {})),
        )

    def load_split(self, split: str, *, limit: int = 0) -> list[EpisodeLabels]:
        records = self.records(split)
        if int(limit) > 0:
            records = records[-int(limit):]
        return [self.load(record) for record in records]


# -----------------------------------------------------------------------------
# Scenario-family normalization
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class FamilyScales:
    """Within-state value scale per family, shrunk toward the global scale."""

    scales: Mapping[str, float]
    global_scale: float
    state_counts: Mapping[str, int]
    prior_strength: float
    floor: float

    def scale(self, family_key: str) -> float:
        """Scale for a family; an unseen family gets the global scale."""
        return float(self.scales.get(str(family_key), self.global_scale))


def family_scales(
    episodes: Iterable[EpisodeLabels],
    *,
    prior_strength: float = 8.0,
    floor: float = 1e-4,
) -> FamilyScales:
    """Root mean within-state variance per family, empirical-Bayes shrunk.

    ``m_f`` is the mean over a family's states of the variance of the
    tape-mean cell values; with ``n_f`` states the shrunk mean square is
    ``(n_f m_f + kappa m_global) / (n_f + kappa)``.  A new family therefore
    starts at the global scale and earns its own as evidence accumulates.
    """
    if float(prior_strength) < 0.0 or float(floor) <= 0.0:
        raise ValueError("prior_strength must be >= 0 and floor > 0")
    sums: dict[str, float] = {}
    counts: dict[str, int] = {}
    for episode in episodes:
        key = episode.family.key
        for decision in episode.decisions:
            variance = decision.within_state_variance()
            if not np.isfinite(variance):
                continue
            sums[key] = sums.get(key, 0.0) + variance
            counts[key] = counts.get(key, 0) + 1
    total_states = sum(counts.values())
    if total_states == 0:
        return FamilyScales({}, float(floor), {}, float(prior_strength), float(floor))
    global_ms = sum(sums.values()) / float(total_states)
    global_scale = max(float(floor), math.sqrt(max(0.0, global_ms)))
    scales = {}
    kappa = float(prior_strength)
    for key, count in counts.items():
        shrunk = (sums[key] + kappa * global_ms) / (count + kappa)
        scales[key] = max(float(floor), math.sqrt(max(0.0, shrunk)))
    return FamilyScales(scales, global_scale, dict(counts), kappa, float(floor))


# -----------------------------------------------------------------------------
# Decision rule
# -----------------------------------------------------------------------------


def ensemble_advantage_statistics(
    samples: np.ndarray, base_actions: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Mean and disagreement of each member's advantage over the base cell.

    The within-state loss identifies each member only up to its own
    per-state level, which is never trained and drifts freely.  The raw
    across-member standard deviation would therefore mix that arbitrary
    level into the uncertainty.  Differencing every member against the base
    action removes it exactly, and the resulting spread is the uncertainty of
    the quantity the rule acts on: the advantage over the base policy (zero,
    with zero spread, at the base cell).  ``samples``: ``(S, M, A)``.
    """
    samples = np.asarray(samples, dtype=np.float64)
    base_actions = np.asarray(base_actions, dtype=np.int64).reshape(-1)
    if samples.ndim != 3 or samples.shape[0] != base_actions.size:
        raise ValueError("samples must have shape (states, members, actions)")
    rows = np.arange(samples.shape[0])
    advantage = samples - samples[rows, :, base_actions][:, :, None]
    return advantage.mean(axis=1), advantage.std(axis=1)



def rule_actions(
    prior: np.ndarray,
    mu: np.ndarray,
    sigma: np.ndarray,
    feasible: np.ndarray,
    base_actions: np.ndarray,
    *,
    lam: float,
    beta: float,
) -> np.ndarray:
    """Actions of the fitted-value decision rule for a batch of states.

    ``lam = 0`` is the base policy exactly (not merely the prior's argmax,
    whose ties could differ).  Shapes: ``(S, A)`` arrays and ``(S,)`` base.
    """
    base_actions = np.asarray(base_actions, dtype=np.int64).reshape(-1)
    if float(lam) <= 0.0:
        return base_actions.copy()
    score = (
        np.asarray(prior, dtype=np.float64)
        + float(lam)
        * (np.asarray(mu, dtype=np.float64) - float(beta) * np.asarray(sigma, dtype=np.float64))
    )
    feasible = np.asarray(feasible, dtype=bool)
    if feasible.shape != score.shape or not bool(np.all(feasible.any(axis=1))):
        raise ValueError("every state needs at least one feasible action")
    score = np.where(feasible, score, -np.inf)
    return np.argmax(score, axis=1).astype(np.int64)


# -----------------------------------------------------------------------------
# Safe-policy-improvement gate
# -----------------------------------------------------------------------------


@dataclass(frozen=True)
class GateStates:
    """Exhaustively labelled holdout states, flattened over episodes."""

    feasible: np.ndarray  # (S, A) bool
    values: np.ndarray  # (S, A) tape-mean value, finite on every feasible cell
    base_actions: np.ndarray  # (S,)
    episode_index: np.ndarray  # (S,) index into episode_ids
    family_index: np.ndarray  # (S,) index into family_keys
    episode_ids: tuple[str, ...]
    family_keys: tuple[str, ...]
    scales: np.ndarray  # (F,) family scale
    decision_index: np.ndarray  # (S,) deployments made before the decision

    @property
    def states(self) -> int:
        return int(self.base_actions.size)

    @property
    def episodes(self) -> int:
        return len(self.episode_ids)

    @classmethod
    def from_episodes(
        cls,
        episodes: Sequence[EpisodeLabels],
        scales: FamilyScales,
    ) -> tuple["GateStates", list[tuple[int, int]]]:
        """Gate states and their ``(episode position, decision position)``.

        Only exhaustive decisions enter the gate: on them every candidate
        rule's action has an exact value, so no rule is scored on a
        selected subset of cells.
        """
        feasible, values, base, episode_index, family_index = [], [], [], [], []
        decision_positions: list[int] = []
        locations: list[tuple[int, int]] = []
        family_keys: list[str] = []
        episode_ids: list[str] = []
        for episode_position, episode in enumerate(episodes):
            rows = [
                (position, decision)
                for position, decision in enumerate(episode.decisions)
                if decision.exhaustive and decision.branched_count >= 1
            ]
            if not rows:
                continue
            key = episode.family.key
            if key not in family_keys:
                family_keys.append(key)
            episode_ids.append(episode.episode_id)
            for position, decision in rows:
                feasible.append(decision.feasible)
                values.append(np.where(decision.feasible, decision.mean_values(), np.nan))
                base.append(decision.base_action)
                decision_positions.append(decision.decision_index)
                episode_index.append(len(episode_ids) - 1)
                family_index.append(family_keys.index(key))
                locations.append((episode_position, position))
        if not base:
            empty = np.zeros((0, 0))
            return (
                cls(empty.astype(bool), empty, np.zeros(0, np.int64), np.zeros(0, np.int64),
                    np.zeros(0, np.int64), (), (), np.zeros(0), np.zeros(0, np.int64)),
                [],
            )
        return (
            cls(
                feasible=np.stack(feasible),
                values=np.stack(values),
                base_actions=np.asarray(base, np.int64),
                episode_index=np.asarray(episode_index, np.int64),
                family_index=np.asarray(family_index, np.int64),
                episode_ids=tuple(episode_ids),
                family_keys=tuple(family_keys),
                scales=np.asarray([scales.scale(key) for key in family_keys], np.float64),
                decision_index=np.asarray(decision_positions, np.int64),
            ),
            locations,
        )


@dataclass(frozen=True)
class ModelPredictions:
    """A model's decision-rule inputs on the gate states."""

    name: str
    prior: np.ndarray  # (S, A)
    mu: np.ndarray  # (S, A) normalized within-state value
    sigma: np.ndarray  # (S, A) ensemble disagreement


@dataclass(frozen=True)
class GateCandidate:
    model: str
    lam: float
    beta: float
    mean_gain: float  # equal-family mean episode gain, normalized units
    lcb: float  # corrected lower bound of mean_gain
    raw_mean_gain: float  # the same in raw return units
    harmful_families: tuple[str, ...]
    certified: bool
    # The first decision's share of mean_gain.  Its state distribution does
    # not depend on the policy, so this component is an exact on-policy
    # performance-difference term; later decisions are a surrogate.
    first_decision_gain: float = 0.0

    def as_dict(self) -> dict:
        return {
            "model": self.model,
            "lambda": self.lam,
            "beta": self.beta,
            "mean_gain": self.mean_gain,
            "first_decision_gain": self.first_decision_gain,
            "lcb": self.lcb,
            "raw_mean_gain": self.raw_mean_gain,
            "harmful_families": list(self.harmful_families),
            "certified": self.certified,
        }


@dataclass(frozen=True)
class GateResult:
    selected: GateCandidate
    candidates: tuple[GateCandidate, ...]
    states: int
    episodes: int
    families: int
    headroom: float  # equal-family mean of per-episode sum of (Q* - Q(b)), normalized
    raw_headroom: float
    alpha: float
    corrected_alpha: float
    draws: int
    reason: str

    @property
    def capture(self) -> float:
        """Share of the exhaustive oracle's improvement the deployed rule certifies."""
        if not np.isfinite(self.headroom) or self.headroom <= 0.0:
            return float("nan")
        return float(self.selected.mean_gain / self.headroom)

    def as_dict(self) -> dict:
        return {
            "selected": self.selected.as_dict(),
            "candidates": [candidate.as_dict() for candidate in self.candidates],
            "states": self.states,
            "episodes": self.episodes,
            "families": self.families,
            "headroom": self.headroom,
            "raw_headroom": self.raw_headroom,
            "capture": self.capture,
            "alpha": self.alpha,
            "corrected_alpha": self.corrected_alpha,
            "draws": self.draws,
            "reason": self.reason,
        }


def _equal_family_episode_weights(episode_family: np.ndarray) -> np.ndarray:
    """Weight ``1 / (F n_f)`` per episode: the weighted mean over episodes is
    the equal-weight mean of family means."""
    families, counts = np.unique(episode_family, return_counts=True)
    per_family = dict(zip(families.tolist(), counts.tolist()))
    total = float(len(per_family))
    return np.asarray(
        [1.0 / (total * float(per_family[int(f)])) for f in episode_family],
        dtype=np.float64,
    )


def _student_bound(values: np.ndarray, weights: np.ndarray, level: float, *, upper: bool) -> float:
    """Cluster-robust Student-t bound on a weighted mean of episode values.

    ``weights`` sum to one.  The variance ``E/(E-1) sum w_e^2 (D_e - m)^2`` is
    the weighted analogue of the usual cluster sandwich; with fewer than two
    episodes no bound exists and the result is ``-inf`` (lower) or ``+inf``.
    """
    from scipy.stats import t as student_t

    values = np.asarray(values, dtype=np.float64)
    weights = np.asarray(weights, dtype=np.float64)
    count = int(values.size)
    if count < 2:
        return float("inf") if upper else float("-inf")
    weights = weights / weights.sum()
    mean = float(np.dot(weights, values))
    variance = float(count / (count - 1.0) * np.sum(weights**2 * (values - mean) ** 2))
    quantile = float(student_t.ppf(1.0 - float(level), df=count - 1))
    half_width = quantile * math.sqrt(max(0.0, variance))
    return mean + half_width if upper else mean - half_width


def _weighted_cluster_bootstrap(
    episode_weights: np.ndarray,
    draws: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """(draws, E) normalized resampling weights for a ratio estimator.

    Episodes (the independent clusters: a scenario and its tape) are
    resampled with replacement from the pooled holdout; each resample's
    estimate is ``sum_e n_e w_e D_e / sum_e n_e w_e``.  Unlike resampling
    within families, this keeps between-episode variance for families that
    have a single holdout episode, which is the common case when the design
    has many scenario cells.
    """
    episodes = int(episode_weights.size)
    counts = rng.multinomial(
        episodes, np.full(episodes, 1.0 / episodes), size=int(draws)
    ).astype(np.float64)
    weighted = counts * episode_weights[None, :]
    totals = weighted.sum(axis=1, keepdims=True)
    return weighted / np.where(totals > 0.0, totals, 1.0)


def safe_improvement_gate(
    states: GateStates,
    models: Sequence[ModelPredictions],
    *,
    lambdas: Sequence[float],
    betas: Sequence[float],
    alpha: float,
    draws: int,
    rng: np.random.Generator,
    minimum_episodes: int,
    harm_minimum_episodes: int = 3,
) -> GateResult:
    """Choose the decision rule to deploy, or keep the base policy.

    For every candidate ``(model, lambda > 0, beta)``: per-state normalized
    gain ``d(s) = (Q(s, a_rule) - Q(s, b(s))) / scale_f``; per-episode sum;
    mean over a family's episodes; equal-weight mean over families.  All
    candidates share the same bootstrap resamples (paired comparison).  A
    candidate is *certified* when its lower bound at level
    ``alpha / K`` (``K`` candidates) is strictly positive and no family with
    at least ``harm_minimum_episodes`` episodes has an upper bound below zero.
    The certified candidate with the largest lower bound is selected; with
    none, or fewer than ``minimum_episodes`` holdout episodes, the base policy
    (``lambda = 0``) is deployed, whose gain is zero by definition.
    """
    lambdas = tuple(float(value) for value in lambdas)
    betas = tuple(float(value) for value in betas)
    if not 0.0 < float(alpha) < 1.0:
        raise ValueError("alpha must lie in (0, 1)")
    if int(draws) < 100:
        raise ValueError("at least 100 bootstrap draws are required")
    positive = [value for value in lambdas if value > 0.0]
    # The last model is the most recent fit (challenger): with no certified
    # candidate, the base rule is deployed on the newest representation.
    base_candidate = GateCandidate(
        model=models[-1].name if models else "base",
        lam=0.0,
        beta=0.0,
        mean_gain=0.0,
        lcb=0.0,
        raw_mean_gain=0.0,
        harmful_families=(),
        certified=True,
    )
    candidate_count = max(1, len(models) * len(positive) * len(betas))
    corrected = float(alpha) / float(candidate_count)
    if states.states == 0 or states.episodes < int(minimum_episodes) or not positive:
        return GateResult(
            selected=base_candidate,
            candidates=(base_candidate,),
            states=states.states,
            episodes=states.episodes,
            families=len(states.family_keys),
            headroom=float("nan"),
            raw_headroom=float("nan"),
            alpha=float(alpha),
            corrected_alpha=corrected,
            draws=int(draws),
            reason=(
                "insufficient_holdout_episodes"
                if states.episodes < int(minimum_episodes)
                else "no_positive_lambda"
            ),
        )
    if not bool(np.all(np.isfinite(states.values[states.feasible]))):
        raise ValueError("gate states must carry an exact value on every feasible cell")

    rows = np.arange(states.states)
    base_values = states.values[rows, states.base_actions]
    state_scale = states.scales[states.family_index]
    episode_family = np.zeros(states.episodes, dtype=np.int64)
    episode_family[states.episode_index] = states.family_index
    family_count = len(states.family_keys)

    def episode_sums(per_state: np.ndarray) -> np.ndarray:
        totals = np.zeros(states.episodes, dtype=np.float64)
        np.add.at(totals, states.episode_index, per_state)
        return totals

    episode_weights = _equal_family_episode_weights(episode_family)

    def equal_family_mean(per_episode: np.ndarray) -> float:
        return float(np.dot(episode_weights, per_episode) / episode_weights.sum())

    oracle = np.nanmax(np.where(states.feasible, states.values, np.nan), axis=1)
    headroom = equal_family_mean(episode_sums((oracle - base_values) / state_scale))
    raw_headroom = equal_family_mean(episode_sums(oracle - base_values))

    weights = _weighted_cluster_bootstrap(episode_weights, int(draws), rng)
    family_members = [
        np.flatnonzero(episode_family == family) for family in range(family_count)
    ]
    family_draws = {
        family: rng.multinomial(
            members.size, np.full(members.size, 1.0 / members.size), size=int(draws)
        ).astype(np.float64) / float(members.size)
        for family, members in enumerate(family_members)
        if members.size >= int(harm_minimum_episodes)
    }
    candidates: list[GateCandidate] = []
    for model in models:
        for lam in positive:
            for beta in betas:
                actions = rule_actions(
                    model.prior,
                    model.mu,
                    model.sigma,
                    states.feasible,
                    states.base_actions,
                    lam=lam,
                    beta=beta,
                )
                raw_gain = states.values[rows, actions] - base_values
                if not bool(np.all(np.isfinite(raw_gain))):
                    raise RuntimeError("a decision rule selected an unlabelled cell")
                per_episode = episode_sums(raw_gain / state_scale)
                mean_gain = equal_family_mean(per_episode)
                first = equal_family_mean(
                    episode_sums(np.where(states.decision_index == 0, raw_gain / state_scale, 0.0))
                )
                resampled = weights @ per_episode
                # The more conservative of the percentile bootstrap and the
                # cluster-robust t bound: the bootstrap alone under-covers
                # with few holdout episodes.
                lcb = min(
                    float(np.quantile(resampled, corrected)),
                    _student_bound(per_episode, episode_weights, corrected, upper=False),
                )
                harmful = []
                for family, resample in family_draws.items():
                    members = family_members[family]
                    family_resampled = resample @ per_episode[members]
                    upper = min(
                        float(np.quantile(family_resampled, 1.0 - corrected)),
                        _student_bound(
                            per_episode[members],
                            np.full(members.size, 1.0 / members.size),
                            corrected,
                            upper=True,
                        ),
                    )
                    if upper < 0.0:
                        harmful.append(states.family_keys[family])
                candidates.append(
                    GateCandidate(
                        model=model.name,
                        lam=lam,
                        beta=beta,
                        mean_gain=mean_gain,
                        lcb=lcb,
                        raw_mean_gain=equal_family_mean(episode_sums(raw_gain)),
                        harmful_families=tuple(harmful),
                        certified=bool(lcb > 0.0 and not harmful),
                        first_decision_gain=first,
                    )
                )
    certified = [candidate for candidate in candidates if candidate.certified]
    if certified:
        # Largest certified bound; ties toward the larger point estimate, then
        # toward the smaller departure from the base policy.
        selected = max(certified, key=lambda c: (c.lcb, c.mean_gain, -c.lam, -c.beta))
        reason = "certified_improvement"
    else:
        selected = GateCandidate(
            model=models[-1].name if models else "base",
            lam=0.0,
            beta=0.0,
            mean_gain=0.0,
            lcb=0.0,
            raw_mean_gain=0.0,
            harmful_families=(),
            certified=True,
        )
        reason = "no_candidate_certified"
    return GateResult(
        selected=selected,
        candidates=tuple(candidates),
        states=states.states,
        episodes=states.episodes,
        families=family_count,
        headroom=headroom,
        raw_headroom=raw_headroom,
        alpha=float(alpha),
        corrected_alpha=corrected,
        draws=int(draws),
        reason=reason,
    )


# -----------------------------------------------------------------------------
# Branch allocation
# -----------------------------------------------------------------------------


def select_fpi_branch_actions(
    feasible_mask: np.ndarray,
    *,
    exhaustive: bool,
    max_branches: int,
    must_include: Sequence[int],
    optimism: Optional[np.ndarray],
    rng: np.random.Generator,
) -> np.ndarray:
    """Cells to branch at a decision.

    Exhaustive states return every feasible cell.  Otherwise the base,
    executed and greedy cells are always included (so the paired gains of
    both the deployed rule and the executed action are exact), half of the
    remaining budget goes to the most optimistic cells under the fitted model
    (where a ranking error would change behavior), and the rest is uniform
    random support, so the label set is not restricted to cells the model
    already likes.
    """
    feasible = np.flatnonzero(np.asarray(feasible_mask, dtype=bool))
    if feasible.size == 0:
        return feasible.astype(np.int64)
    if bool(exhaustive) or feasible.size <= int(max_branches):
        return feasible.astype(np.int64)
    feasible_set = set(int(a) for a in feasible)
    chosen = {int(a) for a in must_include if int(a) in feasible_set}
    budget = max(int(max_branches), len(chosen))
    remaining = [int(a) for a in feasible if int(a) not in chosen]
    free = budget - len(chosen)
    optimistic_slots = (free + 1) // 2
    if optimism is not None and optimistic_slots > 0 and remaining:
        score = np.asarray(optimism, dtype=np.float64)
        ranked = sorted(remaining, key=lambda a: (-score[a], a))
        for action in ranked[:optimistic_slots]:
            chosen.add(action)
        remaining = [a for a in remaining if a not in chosen]
    free = budget - len(chosen)
    if free > 0 and remaining:
        picks = rng.choice(len(remaining), size=min(free, len(remaining)), replace=False)
        chosen.update(remaining[int(i)] for i in picks)
    return np.asarray(sorted(chosen), dtype=np.int64)


# -----------------------------------------------------------------------------
# Paired learning curve and within-state quality
# -----------------------------------------------------------------------------


def paired_gain_summary(
    decisions: Sequence[DecisionLabel],
    *,
    scale: float = 1.0,
) -> dict[str, float]:
    """Exact paired per-episode quantities for one episode's decisions.

    Every quantity is a within-state CRN contrast, so the scenario's own
    severity -- the dominant source of return variance -- cancels:

    * ``greedy_gain``: sum of ``Q(greedy) - Q(base)``, the
      performance-difference estimate of the deployed rule on its own states;
    * ``executed_gain``: the same for the executed (exploratory) action;
    * ``greedy_regret`` / ``base_regret``: ``Q* - Q(.)`` on exhaustive states.
    """
    scale = float(scale) if float(scale) > 0.0 else 1.0
    greedy = [d.gain(d.greedy_action) for d in decisions]
    executed = [d.gain(d.executed_action) for d in decisions]
    exhaustive = [d for d in decisions if d.exhaustive]
    greedy_regret = [
        float(np.nanmax(d.mean_values()) - d.mean_values()[d.greedy_action])
        for d in exhaustive
    ]
    base_regret = [
        float(np.nanmax(d.mean_values()) - d.mean_values()[d.base_action])
        for d in exhaustive
    ]
    return {
        "labelled_states": float(len(decisions)),
        "exhaustive_states": float(len(exhaustive)),
        "branched_mean": float(np.mean([d.branched_count for d in decisions])) if decisions else 0.0,
        "greedy_gain": float(np.sum(greedy)) if greedy else 0.0,
        "executed_gain": float(np.sum(executed)) if executed else 0.0,
        "greedy_gain_normalized": float(np.sum(greedy) / scale) if greedy else 0.0,
        "greedy_regret": float(np.sum(greedy_regret)) if greedy_regret else float("nan"),
        "base_regret": float(np.sum(base_regret)) if base_regret else float("nan"),
        "within_state_sd": float(
            np.nanmean([math.sqrt(v) for v in (d.within_state_variance() for d in decisions)
                        if np.isfinite(v)])
        ) if any(np.isfinite(d.within_state_variance()) for d in decisions) else float("nan"),
    }


def _ranks(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty(values.size, dtype=np.float64)
    ranks[order] = np.arange(values.size, dtype=np.float64)
    for value in np.unique(values):
        tied = values == value
        if tied.sum() > 1:
            ranks[tied] = ranks[tied].mean()
    return ranks


def within_state_quality(
    predictions: np.ndarray,
    values: np.ndarray,
    feasible: np.ndarray,
    prior: Optional[np.ndarray] = None,
    *,
    minimum_cells: int = 3,
) -> dict[str, float]:
    """Held-out ranking quality of a within-state value model.

    ``rank_corr``: mean within-state Spearman over states with at least
    ``minimum_cells`` labelled feasible cells; ``top1``: rate at which the
    model's argmax is the exact best cell; ``prior_top1``: the same for the
    prior, the reference any model must beat.
    """
    correlations, hits, prior_hits = [], [], []
    for index in range(np.asarray(values).shape[0]):
        mask = np.asarray(feasible[index], dtype=bool) & np.isfinite(values[index])
        if int(mask.sum()) < 1:
            continue
        best = int(np.flatnonzero(mask)[int(np.argmax(values[index][mask]))])
        predicted = int(np.flatnonzero(mask)[int(np.argmax(predictions[index][mask]))])
        hits.append(float(predicted == best))
        if prior is not None:
            prior_best = int(np.flatnonzero(mask)[int(np.argmax(prior[index][mask]))])
            prior_hits.append(float(prior_best == best))
        if int(mask.sum()) >= int(minimum_cells):
            a = _ranks(np.asarray(predictions[index][mask], dtype=np.float64))
            b = _ranks(np.asarray(values[index][mask], dtype=np.float64))
            a -= a.mean()
            b -= b.mean()
            denominator = math.sqrt(float(np.dot(a, a) * np.dot(b, b)))
            if denominator > 0.0:
                correlations.append(float(np.dot(a, b) / denominator))
    return {
        "rank_corr": float(np.mean(correlations)) if correlations else float("nan"),
        "top1": float(np.mean(hits)) if hits else float("nan"),
        "prior_top1": float(np.mean(prior_hits)) if prior_hits else float("nan"),
        "states": float(len(hits)),
    }


# -----------------------------------------------------------------------------
# Convergence of fitted policy iteration
# -----------------------------------------------------------------------------

# Convergence audit defaults: the deployed rule's certified holdout gain must
# be stable across refits.  Return stationarity and the PPO KL target do not
# apply to this learner.
FPI_CONVERGENCE_DEFAULTS = {
    "minimum_refits": 8,
    "minimum_gate_episodes": 12,
    "window": 4,
    "gain_tolerance": 0.25,
    "validation_tolerance": 0.02,
}


def add_fpi_convergence_arguments(parser) -> None:
    """CLI thresholds for the fitted-policy-iteration convergence audit."""
    parser.add_argument(
        "--fpi-convergence-min-refits", type=int,
        default=FPI_CONVERGENCE_DEFAULTS["minimum_refits"],
    )
    parser.add_argument(
        "--fpi-convergence-min-gate-episodes", type=int,
        default=FPI_CONVERGENCE_DEFAULTS["minimum_gate_episodes"],
    )
    parser.add_argument(
        "--fpi-convergence-window", type=int, default=FPI_CONVERGENCE_DEFAULTS["window"],
    )
    parser.add_argument(
        "--fpi-convergence-gain-tolerance", type=float,
        default=FPI_CONVERGENCE_DEFAULTS["gain_tolerance"],
    )
    parser.add_argument(
        "--fpi-convergence-validation-tolerance", type=float,
        default=FPI_CONVERGENCE_DEFAULTS["validation_tolerance"],
    )


def fpi_thresholds_from_args(args) -> dict:
    thresholds = {
        "minimum_refits": int(args.fpi_convergence_min_refits),
        "minimum_gate_episodes": int(args.fpi_convergence_min_gate_episodes),
        "window": int(args.fpi_convergence_window),
        "gain_tolerance": float(args.fpi_convergence_gain_tolerance),
        "validation_tolerance": float(args.fpi_convergence_validation_tolerance),
    }
    if (
        thresholds["minimum_refits"] <= 0
        or thresholds["minimum_gate_episodes"] < 0
        or thresholds["window"] <= 0
        or thresholds["gain_tolerance"] < 0.0
        or thresholds["validation_tolerance"] < 0.0
    ):
        raise ValueError("fitted-policy-iteration convergence thresholds must be non-negative")
    return thresholds



FPI_CONVERGENCE_FIELDS = (
    "nmcc_fpi_refit_index",
    "nmcc_fpi_gate_episodes",
    "nmcc_fpi_gate_mean_gain",
    "nmcc_fpi_gate_lcb",
    "nmcc_fpi_deployed_lambda",
    "nmcc_fpi_deployed_beta",
    "nmcc_fpi_refit_validation_loss",
)


def fpi_convergence(
    update_rows: Sequence[Mapping],
    *,
    minimum_refits: int,
    minimum_gate_episodes: int,
    window: int,
    gain_tolerance: float,
    validation_tolerance: float,
) -> dict:
    """Has fitted policy iteration reached a data-stable fixed point?

    ``update_rows`` are the diagnostics of refit events in order.  Converged
    means: enough refits and exhaustive holdout episodes; finite diagnostics;
    over the last ``window`` refits the deployed rule's certified gain moved
    by at most ``gain_tolerance`` (normalized, per episode) and its lower bound
    stayed non-negative; and the best validation loss improved by less than
    ``validation_tolerance`` (relative) across the window.  More labels are
    then no longer changing what is deployed.  Return stationarity of
    unpaired training episodes is deliberately not used: its scenario noise
    exceeds any achievable policy effect at feasible sample sizes.
    """
    rows = list(update_rows)
    finite = all(
        all(np.isfinite(float(row.get(name, float("nan")))) for name in FPI_CONVERGENCE_FIELDS
            if name != "nmcc_fpi_refit_validation_loss")
        for row in rows
    )
    refits = len(rows)
    gate_episodes = int(float(rows[-1].get("nmcc_fpi_gate_episodes", 0))) if rows else 0
    window = int(window)
    tail = rows[-window:] if window > 0 else []
    gains = np.asarray([float(row.get("nmcc_fpi_gate_mean_gain", np.nan)) for row in tail])
    lcbs = np.asarray([float(row.get("nmcc_fpi_gate_lcb", np.nan)) for row in tail])
    validation = np.asarray(
        [float(row.get("nmcc_fpi_refit_validation_loss", np.nan)) for row in tail]
    )
    gain_span = float(np.nanmax(gains) - np.nanmin(gains)) if gains.size and np.isfinite(gains).any() else float("inf")
    finite_validation = validation[np.isfinite(validation)]
    if finite_validation.size >= 2 and finite_validation[0] > 0.0:
        validation_change = float(
            (finite_validation[0] - finite_validation.min()) / finite_validation[0]
        )
    elif finite_validation.size >= 2:
        validation_change = 0.0
    else:
        validation_change = float("inf")
    converged = bool(
        finite
        and refits >= int(minimum_refits)
        and gate_episodes >= int(minimum_gate_episodes)
        and len(tail) == window
        and gain_span <= float(gain_tolerance)
        and bool(np.all(lcbs >= 0.0))
        and validation_change <= float(validation_tolerance)
    )
    return {
        "refits": refits,
        "gate_episodes": gate_episodes,
        "window_refits": len(tail),
        "all_diagnostics_finite": finite,
        "tail_gate_gain_span": gain_span,
        "tail_gate_gain_last": float(gains[-1]) if gains.size else float("nan"),
        "tail_gate_lcb_minimum": float(np.nanmin(lcbs)) if lcbs.size and np.isfinite(lcbs).any() else float("nan"),
        "tail_validation_relative_improvement": validation_change,
        "deployed_lambda": float(rows[-1].get("nmcc_fpi_deployed_lambda", 0.0)) if rows else 0.0,
        "deployed_beta": float(rows[-1].get("nmcc_fpi_deployed_beta", 0.0)) if rows else 0.0,
        "converged": converged,
    }
