#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Properties of the evacuation reward that the v26 learner relies on.

* **Ordering.**  Per person, safe completion is never worse than remaining
  unfinished, and a casualty is always the worst outcome, whatever the timing
  and hazard exposure.
* **Additivity.**  Scoring timestep by timestep (as every branch does) sums
  exactly to scoring one decision interval at once (as the bridge does), so
  branch labels and training transitions measure the same objective.
* **Scale invariance.**  Multiplying the population and every count by the
  same factor leaves the reward unchanged, so returns are comparable across
  pedestrian volumes.  What does *not* stay invariant is the value of one
  fixed-capacity shelter, which scales like capacity / population: that is why
  fitted policy iteration normalizes within-state contrasts per scenario
  family instead of pooling raw squared errors.
"""

import unittest

import numpy as np

from DecisionInterface import OutcomeSnapshot
from RewardProcessor import RewardProcessor


def snapshot(safe, casualties, active, risk):
    return OutcomeSnapshot(
        safe_completed=safe,
        casualties=casualties,
        shelter_evacuated=0,
        ordinary_arrivals=safe,
        active_population=active,
        risk_mass=risk,
    )


class RewardContractTests(unittest.TestCase):
    def setUp(self):
        self.reward = RewardProcessor()
        self.population = 100
        self.horizon = 60

    def person_return(self, outcome: str, time: int, exposure: float) -> float:
        """Return contributed by one person who is active until ``time``."""
        active_time = float(time)
        exposure_time = float(time) * float(exposure)
        before = snapshot(0, 0, 1, 1.0 + exposure)
        after = snapshot(
            int(outcome == "safe"), int(outcome == "casualty"), int(outcome == "unfinished"),
            (1.0 + exposure) if outcome == "unfinished" else 0.0,
        )
        return self.reward.evaluate(
            before=before, after=after, active_person_time=active_time,
            hazard_exposure_person_time=exposure_time,
            initial_population=self.population, horizon=self.horizon,
        ).total

    def test_outcome_ordering_holds_for_every_timing_and_exposure(self):
        for exposure in (0.0, 0.5, 1.0):
            unfinished = self.person_return("unfinished", self.horizon, exposure)
            for time in (1, 20, self.horizon):
                safe = self.person_return("safe", time, exposure)
                self.assertGreaterEqual(safe, unfinished - 1e-12)
            for time in (1, 20, self.horizon):
                casualty = self.person_return("casualty", time, exposure)
                self.assertLess(casualty, unfinished)
                self.assertLess(casualty, self.person_return("safe", self.horizon, 1.0))

    def test_weights_that_would_reward_casualties_are_refused(self):
        with self.assertRaises(ValueError):
            RewardProcessor(casualty_weight=2.0)

    def test_per_step_scoring_sums_to_interval_scoring(self):
        rng = np.random.default_rng(0)
        states = [snapshot(0, 0, 100, 150.0)]
        for _ in range(10):
            previous = states[-1]
            safe = previous.safe_completed + int(rng.integers(0, 4))
            casualties = previous.casualties + int(rng.integers(0, 2))
            active = 100 - safe - casualties
            states.append(snapshot(safe, casualties, active, active * (1.0 + rng.random())))
        stepwise = 0.0
        for before, after in zip(states, states[1:]):
            stepwise += self.reward.evaluate(
                before=before, after=after, active_person_time=float(after.active_population),
                hazard_exposure_person_time=float(after.hazard_exposure_mass),
                initial_population=100, horizon=60,
            ).total
        interval = self.reward.evaluate(
            before=states[0], after=states[-1],
            active_person_time=float(sum(s.active_population for s in states[1:])),
            hazard_exposure_person_time=float(sum(s.hazard_exposure_mass for s in states[1:])),
            initial_population=100, horizon=60,
        ).total
        self.assertAlmostEqual(stepwise, interval, places=12)

    def test_reward_is_invariant_to_population_scale(self):
        def total(k):
            return self.reward.evaluate(
                before=snapshot(0, 0, 100 * k, 150.0 * k),
                after=snapshot(30 * k, 5 * k, 65 * k, 90.0 * k),
                active_person_time=800.0 * k, hazard_exposure_person_time=300.0 * k,
                initial_population=100 * k, horizon=60,
            ).total
        self.assertAlmostEqual(total(1), total(25), places=12)

    def test_one_fixed_capacity_shelter_is_worth_less_in_a_larger_population(self):
        """500 extra safe completions: the cross-scenario scale the learner normalizes."""
        def gain(population):
            base = snapshot(0, 0, population, float(population))
            return self.reward.evaluate(
                before=base, after=snapshot(500, 0, population - 500, float(population - 500)),
                active_person_time=0.0, hazard_exposure_person_time=0.0,
                initial_population=population, horizon=60,
            ).total
        self.assertAlmostEqual(gain(5000) / gain(25000), 5.0, places=9)


if __name__ == "__main__":
    unittest.main()
