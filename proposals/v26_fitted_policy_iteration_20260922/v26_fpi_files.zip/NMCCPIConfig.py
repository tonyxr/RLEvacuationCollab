# -*- coding: utf-8 -*-
"""Torch-free configuration contract for NMCC policy improvement (NMCC-PI)
and the learner's representation-ownership mode.

Shared by Core (defaults, casting, recorded configuration), RLBridge
(constructor defaults) and TrainingCurriculum (the learner keys a curriculum
may set and must hold constant), so that none of them has to import torch to
agree on names, types or defaults.
"""

# Must equal GNN.HEURISTIC_PRIOR_SCALE; checked by tests/test_nmcc_pi_torch.py.
DEFAULT_ACTOR_PRIOR_SCALE = 1.0

DEFAULT_NMCC_PI_EPSILON = 0.5  # E-step KL(q || pi_old) per decision state
DEFAULT_NMCC_PI_ETA_MIN = 0.03  # temperature floor ~ single-tape contrast SE
DEFAULT_NMCC_PI_KL_CAP = 0.6  # M-step mean KL(pi_new || pi_old): the E-step direction, >= epsilon
DEFAULT_NMCC_PI_TAPES = 1
DEFAULT_NMCC_PI_EXHAUSTIVE_DECISIONS = 2
DEFAULT_NMCC_PI_MAX_BRANCHES = 6
DEFAULT_NMCC_PI_VALUE_SCALE = 0.05  # return units per unit of head output
DEFAULT_NMCC_PI_VALUE_LOSS_COEF = 1.0
DEFAULT_NMCC_PI_GATE_SPEARMAN = 0.6
DEFAULT_NMCC_PI_GATE_UPDATES = 3
DEFAULT_NMCC_PI_MODEL_UNCERTAINTY_PENALTY = 1.0
DEFAULT_NMCC_PI_ACTOR_EPOCHS = 32
DEFAULT_NMCC_PI_FIT_TOLERANCE = 0.2
DEFAULT_NMCC_PI_BRANCH_HORIZON = 20
DEFAULT_NMCC_PI_ACTOR_OBJECTIVE = "score_ranking"
DEFAULT_NMCC_PI_RANKING_TEMPERATURE = 0.05
DEFAULT_NMCC_PI_RANK_MARGIN = 0.25
DEFAULT_NMCC_PI_RANK_MARGIN_COEF = 0.5
DEFAULT_EXPLORATION_RATE_START = 0.30
DEFAULT_EXPLORATION_RATE_END = 0.02
DEFAULT_LR_SCHEDULE = "cosine"
DEFAULT_LR_WARMUP_UPDATES = 1
DEFAULT_LR_DECAY_UPDATES = 32
DEFAULT_ACTOR_LR_MIN_FRACTION = 0.10
DEFAULT_CRITIC_LR_MIN_FRACTION = 0.20

# NMCC actor objectives.  ``fitted_value`` (model version 26) is rollout-
# labelled fitted policy iteration: a persistent label store, a refit of the
# whole network on it, and a safe-policy-improvement gate between the fitted
# within-state value ensemble and the executed decision rule
# (FittedPolicyIteration.py).  The other two are the v24/v25 actor fits.
NMCC_PI_ACTOR_OBJECTIVES = ("kl_target", "score_ranking", "fitted_value")
# ``nmccPiBranchHorizon = 0`` branches to the true episode horizon.
NMCC_PI_FULL_HORIZON = 0

DEFAULT_NMCC_FPI_HOLDOUT_FRACTION = 0.20
DEFAULT_NMCC_FPI_VALIDATION_FRACTION = 0.10
DEFAULT_NMCC_FPI_LAMBDA_GRID = "0,0.5,2,8"
DEFAULT_NMCC_FPI_BETA_GRID = "0,1"
DEFAULT_NMCC_FPI_GATE_ALPHA = 0.10
DEFAULT_NMCC_FPI_GATE_DRAWS = 4000
DEFAULT_NMCC_FPI_GATE_MINIMUM_EPISODES = 6
DEFAULT_NMCC_FPI_HARM_MINIMUM_EPISODES = 3
DEFAULT_NMCC_FPI_REFIT_MODE = "scratch"
DEFAULT_NMCC_FPI_REFIT_MAX_EPOCHS = 60
DEFAULT_NMCC_FPI_REFIT_PATIENCE = 8
DEFAULT_NMCC_FPI_LEARNING_RATE = 1e-3
DEFAULT_NMCC_FPI_WEIGHT_DECAY = 1e-4
DEFAULT_NMCC_FPI_MINIBATCH_EPISODES = 8
DEFAULT_NMCC_FPI_AUXILIARY_LOSS_COEF = 0.25
DEFAULT_NMCC_FPI_FAMILY_PRIOR_STRENGTH = 8.0
DEFAULT_NMCC_FPI_OPTIMISM = 1.0
DEFAULT_NMCC_FPI_MAX_STORE_EPISODES = 0  # 0 keeps every committed fit episode

# Learner representation contract (see RLBridge._optimize_policy).
REPRESENTATION_MODES = ("actor_owned", "shared_phasic")
DEFAULT_REPRESENTATION_MODE = "actor_owned"  # legacy: encoder/LSTM trained by the actor only
DEFAULT_REPRESENTATION_CLONE_COEF = 1.0  # PPG-style policy-preservation weight
DEFAULT_REPRESENTATION_KL_CAP = 0.05  # max policy drift a critic/auxiliary pass may cause

# Core attribute -> (RLBridge keyword, type, default).  One table drives the
# Core defaults, casting, constructor wiring and the recorded effective
# configuration, so an NMCC-PI setting cannot be accepted by one layer and
# silently dropped by another.
NMCC_PI_CORE_FIELDS = (
    ("nmccPolicyImprovement", "nmcc_policy_improvement", bool, False),
    ("nmccPiEpsilon", "nmcc_pi_epsilon", float, DEFAULT_NMCC_PI_EPSILON),
    ("nmccPiEtaMin", "nmcc_pi_eta_min", float, DEFAULT_NMCC_PI_ETA_MIN),
    ("nmccPiKlCap", "nmcc_pi_kl_cap", float, DEFAULT_NMCC_PI_KL_CAP),
    ("nmccPiTapes", "nmcc_pi_tapes", int, DEFAULT_NMCC_PI_TAPES),
    (
        "nmccPiExhaustiveDecisions",
        "nmcc_pi_exhaustive_decisions",
        int,
        DEFAULT_NMCC_PI_EXHAUSTIVE_DECISIONS,
    ),
    ("nmccPiMaxBranches", "nmcc_pi_max_branches", int, DEFAULT_NMCC_PI_MAX_BRANCHES),
    ("nmccPiBasePolicy", "nmcc_pi_base_policy", str, "route_saving"),
    ("nmccPiValueScale", "nmcc_pi_value_scale", float, DEFAULT_NMCC_PI_VALUE_SCALE),
    (
        "nmccPiValueLossCoefficient",
        "nmcc_pi_value_loss_coef",
        float,
        DEFAULT_NMCC_PI_VALUE_LOSS_COEF,
    ),
    ("nmccPiModelFill", "nmcc_pi_model_fill", bool, False),
    ("nmccPiGateSpearman", "nmcc_pi_gate_spearman", float, DEFAULT_NMCC_PI_GATE_SPEARMAN),
    ("nmccPiGateUpdates", "nmcc_pi_gate_updates", int, DEFAULT_NMCC_PI_GATE_UPDATES),
    (
        "nmccPiModelUncertaintyPenalty",
        "nmcc_pi_model_uncertainty_penalty",
        float,
        DEFAULT_NMCC_PI_MODEL_UNCERTAINTY_PENALTY,
    ),
    ("nmccPiActorEpochs", "nmcc_pi_actor_epochs", int, DEFAULT_NMCC_PI_ACTOR_EPOCHS),
    ("nmccPiFitTolerance", "nmcc_pi_fit_tolerance", float, DEFAULT_NMCC_PI_FIT_TOLERANCE),
    (
        "nmccPiBranchHorizon",
        "nmcc_pi_branch_horizon",
        int,
        DEFAULT_NMCC_PI_BRANCH_HORIZON,
    ),
    (
        "nmccPiActorObjective",
        "nmcc_pi_actor_objective",
        str,
        DEFAULT_NMCC_PI_ACTOR_OBJECTIVE,
    ),
    (
        "nmccPiRankingTemperature",
        "nmcc_pi_ranking_temperature",
        float,
        DEFAULT_NMCC_PI_RANKING_TEMPERATURE,
    ),
    ("nmccPiRankMargin", "nmcc_pi_rank_margin", float, DEFAULT_NMCC_PI_RANK_MARGIN),
    (
        "nmccPiRankMarginCoefficient",
        "nmcc_pi_rank_margin_coef",
        float,
        DEFAULT_NMCC_PI_RANK_MARGIN_COEF,
    ),
    (
        "explorationRateStart",
        "exploration_rate_start",
        float,
        DEFAULT_EXPLORATION_RATE_START,
    ),
    (
        "explorationRateEnd",
        "exploration_rate_end",
        float,
        DEFAULT_EXPLORATION_RATE_END,
    ),
    ("learningRateSchedule", "learning_rate_schedule", str, DEFAULT_LR_SCHEDULE),
    ("learningRateWarmupUpdates", "lr_warmup_updates", int, DEFAULT_LR_WARMUP_UPDATES),
    ("learningRateDecayUpdates", "lr_decay_updates", int, DEFAULT_LR_DECAY_UPDATES),
    (
        "actorLearningRateMinimumFraction",
        "actor_lr_min_fraction",
        float,
        DEFAULT_ACTOR_LR_MIN_FRACTION,
    ),
    (
        "criticLearningRateMinimumFraction",
        "critic_lr_min_fraction",
        float,
        DEFAULT_CRITIC_LR_MIN_FRACTION,
    ),
    ("actorPrior", "actor_prior", str, "active_population"),
    ("actorPriorScale", "actor_prior_scale", float, DEFAULT_ACTOR_PRIOR_SCALE),
    ("representationMode", "representation_mode", str, DEFAULT_REPRESENTATION_MODE),
    (
        "representationCloneCoefficient",
        "representation_clone_coef",
        float,
        DEFAULT_REPRESENTATION_CLONE_COEF,
    ),
    ("representationKlCap", "representation_kl_cap", float, DEFAULT_REPRESENTATION_KL_CAP),
    # --- Decision interface (model version 26) ------------------------------
    # Token catch-up applies to every strategy, learned or benchmark, so the
    # realized shelter capacity of compared policies is the same whenever a
    # safe cell exists.  Scenario descriptors add the operator-known panic
    # susceptibility, population and hazard-source count to the global
    # features.  Both default off, which is the historical contract.
    ("shelterDecisionCatchUp", "decision_catch_up", bool, False),
    ("scenarioDescriptors", "scenario_descriptors", bool, False),
    # --- Rollout-labelled fitted policy iteration (nmccPiActorObjective =
    # "fitted_value") ---------------------------------------------------------
    # The store path and the collect-only flag are process settings: they are
    # recorded but excluded from the checkpoint training signature, so
    # parallel label collectors can run from the learner's checkpoint.
    ("nmccFpiLabelStore", "nmcc_fpi_label_store", str, ""),
    ("nmccFpiCollectOnly", "nmcc_fpi_collect_only", bool, False),
    (
        "nmccFpiHoldoutFraction",
        "nmcc_fpi_holdout_fraction",
        float,
        DEFAULT_NMCC_FPI_HOLDOUT_FRACTION,
    ),
    (
        "nmccFpiValidationFraction",
        "nmcc_fpi_validation_fraction",
        float,
        DEFAULT_NMCC_FPI_VALIDATION_FRACTION,
    ),
    ("nmccFpiLambdaGrid", "nmcc_fpi_lambda_grid", str, DEFAULT_NMCC_FPI_LAMBDA_GRID),
    ("nmccFpiBetaGrid", "nmcc_fpi_beta_grid", str, DEFAULT_NMCC_FPI_BETA_GRID),
    ("nmccFpiGateAlpha", "nmcc_fpi_gate_alpha", float, DEFAULT_NMCC_FPI_GATE_ALPHA),
    (
        "nmccFpiGateBootstrapDraws",
        "nmcc_fpi_gate_draws",
        int,
        DEFAULT_NMCC_FPI_GATE_DRAWS,
    ),
    (
        "nmccFpiGateMinimumEpisodes",
        "nmcc_fpi_gate_minimum_episodes",
        int,
        DEFAULT_NMCC_FPI_GATE_MINIMUM_EPISODES,
    ),
    (
        "nmccFpiHarmMinimumEpisodes",
        "nmcc_fpi_harm_minimum_episodes",
        int,
        DEFAULT_NMCC_FPI_HARM_MINIMUM_EPISODES,
    ),
    ("nmccFpiRefitMode", "nmcc_fpi_refit_mode", str, DEFAULT_NMCC_FPI_REFIT_MODE),
    (
        "nmccFpiRefitMaxEpochs",
        "nmcc_fpi_refit_max_epochs",
        int,
        DEFAULT_NMCC_FPI_REFIT_MAX_EPOCHS,
    ),
    (
        "nmccFpiRefitPatience",
        "nmcc_fpi_refit_patience",
        int,
        DEFAULT_NMCC_FPI_REFIT_PATIENCE,
    ),
    ("nmccFpiLearningRate", "nmcc_fpi_learning_rate", float, DEFAULT_NMCC_FPI_LEARNING_RATE),
    ("nmccFpiWeightDecay", "nmcc_fpi_weight_decay", float, DEFAULT_NMCC_FPI_WEIGHT_DECAY),
    (
        "nmccFpiMinibatchEpisodes",
        "nmcc_fpi_minibatch_episodes",
        int,
        DEFAULT_NMCC_FPI_MINIBATCH_EPISODES,
    ),
    (
        "nmccFpiAuxiliaryLossCoefficient",
        "nmcc_fpi_auxiliary_loss_coef",
        float,
        DEFAULT_NMCC_FPI_AUXILIARY_LOSS_COEF,
    ),
    (
        "nmccFpiFamilyPriorStrength",
        "nmcc_fpi_family_prior_strength",
        float,
        DEFAULT_NMCC_FPI_FAMILY_PRIOR_STRENGTH,
    ),
    ("nmccFpiOptimism", "nmcc_fpi_optimism", float, DEFAULT_NMCC_FPI_OPTIMISM),
    ("nmccFpiWaitBranch", "nmcc_fpi_wait_branch", bool, True),
    (
        "nmccFpiMaxStoreEpisodes",
        "nmcc_fpi_max_store_episodes",
        int,
        DEFAULT_NMCC_FPI_MAX_STORE_EPISODES,
    ),
)

# Process-level settings: recorded in the effective configuration, never part
# of a checkpoint's training signature, and not declared by curricula.
NMCC_FPI_PROCESS_KEYWORDS = frozenset({"nmcc_fpi_label_store", "nmcc_fpi_collect_only"})
NMCC_FPI_PROCESS_ATTRIBUTES = frozenset({"nmccFpiLabelStore", "nmccFpiCollectOnly"})
# Rows added at model version 26.  Earlier curricula predate them and rely on
# their defaults, which reproduce the historical behavior.
NMCC_V26_ATTRIBUTES = frozenset(
    {"shelterDecisionCatchUp", "scenarioDescriptors"}
    | {attribute for attribute, _, _, _ in NMCC_PI_CORE_FIELDS if attribute.startswith("nmccFpi")}
)
