#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RLBridge/GNN-side tests for rollout-labelled fitted policy iteration (v26).

These require torch and therefore the project's pinned ``rlevacuation``
environment.  The torch-free core (store, splits, family scales, decision
rule, gate, schedule, allocation, convergence) is covered in
``tests/test_fitted_policy_iteration.py``.

What is pinned here is the learner contract:

* configuration errors are refused, and v26 settings default off;
* with ``lambda = 0`` the executed rule is the base policy at every decision;
* one training episode commits one shard whose labels cover every decision,
  are exhaustive where required, and branch the base/executed/greedy cells;
* the batched recurrent replay used for refitting reproduces the live
  forward pass exactly, and batching episodes together changes nothing;
* a refit trains the network, the gate falls back to the base policy without
  holdout evidence, and the deployed rule survives a checkpoint round trip
  into an evaluation bridge;
* the within-state loss is blind to any cell-independent level;
* catch-up never deploys more than the accrued authorizations, the
  route-saving benchmark is the base policy, and scenario descriptors extend
  the global features.
"""

import dataclasses
import json
import os
import tempfile
import unittest

import numpy as np
import torch

import CounterfactualBranch as CB
import FittedPolicyIteration as FPI
import NMCCPolicyImprovement as NPI
import nmcc_testbed
from DecisionInterface import GLOBAL_FEATURE_NAMES, SCENARIO_FEATURE_NAMES, scenario_descriptor
from RLBridge import RLBridge


def testbed(seed: int = 123):
    return nmcc_testbed.build(
        grid=8,
        cell_x=3,
        cell_y=3,
        population=90,
        stop_time=24,
        spread_rate=(6, 3),
        casualty_rate=(40, 9),
        panic_rate=0.5,
        hazard_count=2,
        scenario_seed=seed,
        spacing_m=150,
        candidate_count=8,
        shelter_capacity_token=30,
    )


def fpi_bridge(core, directory, **overrides):
    # Budget 3 (two initial shelters): decisions at t = 1, 7, 13, so replay
    # exercises the recurrence over many frames and unequal episode lengths.
    settings = dict(
        train_mode=True,
        deployment_strategy="rl",
        target_active_shelters=5,
        shelter_action_interval=6,
        policy_seed=7,
        rollout_episodes=2,
        checkpoint_path=os.path.join(directory, "policy.pt"),
        diagnostics_path=os.path.join(directory, "diagnostics.csv"),
        nmcc_policy_improvement=True,
        nmcc_pi_actor_objective="fitted_value",
        nmcc_pi_branch_horizon=0,
        nmcc_pi_exhaustive_decisions=1,
        nmcc_pi_max_branches=4,
        nmcc_ensemble_size=3,
        actor_prior="route_time_saving",
        action_temperature_start=1.0,
        action_temperature_end=1.0,
        nmcc_fpi_holdout_fraction=0.0,
        nmcc_fpi_validation_fraction=0.0,
        nmcc_fpi_refit_max_epochs=3,
        nmcc_fpi_refit_patience=2,
        nmcc_fpi_minibatch_episodes=2,
        nmcc_fpi_gate_draws=200,
        nmcc_fpi_gate_minimum_episodes=1,
        decision_catch_up=True,
        scenario_descriptors=True,
    )
    settings.update(overrides)
    rl = RLBridge(core, **settings)
    core.rl = rl
    return rl


def run_episode(core, rl, *, finalize=False):
    for step in range(1, int(core.stopTime)):
        CB.advance_one_timestep(core)
        rl.step(simulation_time=step, is_terminal=(step == core.stopTime - 1))
    return rl.end_episode(finalize_rollout=finalize)


def capture_live_samples(rl):
    """Record the live value-ensemble output at every labelled decision."""
    live = []
    original = rl._collect_fpi_label

    def wrapped(observation, recurrent_step, decision, *, simulation_time):
        live.append(
            recurrent_step.improvement_value_samples.detach().clone().reshape(
                rl.nmcc_ensemble_size, -1
            )
        )
        return original(observation, recurrent_step, decision, simulation_time=simulation_time)

    rl._collect_fpi_label = wrapped
    return live


class ContractTests(unittest.TestCase):
    def test_v26_settings_default_off(self):
        with tempfile.TemporaryDirectory() as directory:
            rl = RLBridge(
                testbed(),
                train_mode=True,
                deployment_strategy="rl",
                target_active_shelters=3,
                shelter_action_interval=6,
                checkpoint_path=os.path.join(directory, "p.pt"),
            )
        self.assertFalse(rl.fitted_value)
        self.assertFalse(rl.decision_catch_up)
        self.assertFalse(rl.scenario_descriptors)
        self.assertEqual(rl.d_global, len(GLOBAL_FEATURE_NAMES))
        signature = rl._model_signature()
        self.assertIsNone(signature["nmcc_policy_improvement"]["fitted_policy_iteration"])
        self.assertEqual(signature["decision_rule"], {"kind": "actor_logits"})
        self.assertEqual(signature["decision_schedule"]["token_rule"], "scheduled_epochs_only")

    def test_invalid_settings_are_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            core = testbed()
            with self.assertRaises(ValueError):
                fpi_bridge(core, directory, nmcc_policy_improvement=False)
            with self.assertRaises(ValueError):
                fpi_bridge(core, directory, nmcc_natural_pretrain_rollouts=1)
            with self.assertRaises(ValueError):
                fpi_bridge(core, directory, nmcc_fpi_lambda_grid="0.5,1")
            with self.assertRaises(ValueError):
                fpi_bridge(core, directory, nmcc_fpi_holdout_fraction=0.6,
                           nmcc_fpi_validation_fraction=0.5)
            with self.assertRaises(ValueError):
                fpi_bridge(core, directory, nmcc_fpi_refit_mode="partial")
            with self.assertRaises(ValueError):
                fpi_bridge(core, directory, nmcc_pi_branch_horizon=-1)
            with self.assertRaises(ValueError):
                RLBridge(core, train_mode=True, deployment_strategy="rl",
                         target_active_shelters=3, nmcc_fpi_collect_only=True,
                         checkpoint_path=os.path.join(directory, "x.pt"))

    def test_process_settings_are_not_part_of_the_training_signature(self):
        with tempfile.TemporaryDirectory() as directory:
            a = fpi_bridge(testbed(), directory)
            b = fpi_bridge(
                testbed(), directory,
                nmcc_fpi_label_store=os.path.join(directory, "elsewhere"),
                nmcc_fpi_collect_only=True,
            )
            self.assertEqual(a._model_signature(), b._model_signature())
            c = fpi_bridge(testbed(), directory, nmcc_pi_base_policy="active_population")
            self.assertNotEqual(
                FPI.contract_digest(a._fpi_label_contract()),
                FPI.contract_digest(c._fpi_label_contract()),
            )


class EpisodeTests(unittest.TestCase):
    def test_episode_commits_exact_labels_and_replay_matches_live(self):
        with tempfile.TemporaryDirectory() as directory:
            core = testbed(123)
            rl = fpi_bridge(core, directory)
            live = capture_live_samples(rl)
            result = run_episode(core, rl)
            self.assertEqual(result["optimizer_updated"], 0.0)  # 1 of 2 rollout episodes
            self.assertEqual(result["nmcc_fpi_enabled"], 1.0)
            store = rl._fpi_store()
            records = store.records()
            self.assertEqual(len(records), 1)
            episode = store.load(records[0])
            self.assertEqual(len(episode.decisions), len(live))
            self.assertEqual(len(episode.decisions), int(result["decisions"]))
            self.assertTrue(episode.decisions[0].exhaustive)
            for decision in episode.decisions:
                branched = decision.branched
                self.assertTrue(branched[decision.base_action])
                self.assertTrue(branched[decision.executed_action])
                self.assertTrue(branched[decision.greedy_action])
                # lambda = 0: the deployed rule is the base policy exactly.
                self.assertEqual(decision.greedy_action, decision.base_action)
                self.assertTrue(np.all(np.isfinite(decision.values[:, branched])))
            self.assertEqual(episode.family.key, rl.scenario_family.key)

            replay = rl._fpi_sequences(store, [episode])
            with torch.no_grad():
                outputs = rl._fpi_forward(replay)
            self.assertEqual(len(outputs["index"]), len(live))
            for row, (_, label_index) in enumerate(outputs["index"]):
                torch.testing.assert_close(
                    outputs["samples"][row], live[label_index], atol=1e-5, rtol=1e-5
                )

            payload = torch.load(rl.checkpoint_path, map_location="cpu", weights_only=False)
            self.assertEqual(payload["fpi_state"]["lambda"], 0.0)
            self.assertEqual(payload["rollout_transitions"], [])
            self.assertEqual(payload["rollout_episode_count"], 1)

    def test_batched_replay_equals_per_episode_replay(self):
        with tempfile.TemporaryDirectory() as directory:
            for seed in (123, 456):
                core = testbed(seed)
                rl = fpi_bridge(core, directory, rollout_episodes=3)
                run_episode(core, rl)
            store = rl._fpi_store()
            episodes = [store.load(record) for record in store.records()]
            self.assertEqual(len(episodes), 2)
            sequences = rl._fpi_sequences(store, episodes)
            self.assertGreater(len(sequences[0].frames), 1)
            # A truncated copy guarantees unequal lengths, so the lock-step
            # replay must shrink its active set and slice the LSTM state.
            first = sequences[0]
            cut = first.decision_positions[0] + 1
            sequences.append(
                dataclasses.replace(
                    first,
                    frames=first.frames[:cut],
                    decision_positions=first.decision_positions[:1],
                    labels=first.labels[:1],
                )
            )
            with torch.no_grad():
                together = rl._fpi_forward(sequences)
                separate = [rl._fpi_forward([sequence]) for sequence in sequences]
            lookup = {key: row for row, key in enumerate(together["index"])}
            for sequence_index, outputs in enumerate(separate):
                for row, (_, label_index) in enumerate(outputs["index"]):
                    torch.testing.assert_close(
                        together["samples"][lookup[(sequence_index, label_index)]],
                        outputs["samples"][row],
                        atol=1e-5,
                        rtol=1e-5,
                    )

    def test_refit_gate_and_evaluation_round_trip(self):
        with tempfile.TemporaryDirectory() as directory:
            core = testbed(123)
            rl = fpi_bridge(core, directory, rollout_episodes=1)
            before = {name: tensor.clone() for name, tensor in rl.policy.state_dict().items()}
            result = run_episode(core, rl)
            self.assertEqual(result["optimizer_updated"], 1.0)
            self.assertEqual(result["nmcc_fpi_refit_index"], 1.0)
            self.assertGreaterEqual(result["nmcc_fpi_refit_epochs"], 1.0)
            self.assertEqual(result["nmcc_fpi_store_fit_episodes"], 1.0)
            # No holdout evidence yet: the base policy stays deployed.
            self.assertEqual(result["nmcc_fpi_deployed_lambda"], 0.0)
            self.assertEqual(result["nmcc_fpi_gate_certified"], 0.0)
            changed = any(
                not torch.equal(before[name], tensor)
                for name, tensor in rl.policy.state_dict().items()
                if name.startswith("improvement_value_heads")
            )
            self.assertTrue(changed)
            with open(f"{rl.checkpoint_path}.fpi_gate.jsonl", encoding="utf-8") as handle:
                record = json.loads(handle.readline())
            self.assertEqual(record["gate"]["reason"], "insufficient_holdout_episodes")

            # A holdout episode is branched exhaustively at every decision.
            core = testbed(789)
            rl = fpi_bridge(core, directory, rollout_episodes=1)
            rl.fpi_split = "holdout"
            run_episode(core, rl)
            holdout = rl._fpi_store().load_split("holdout")
            self.assertEqual(len(holdout), 1)
            self.assertTrue(all(decision.exhaustive for decision in holdout[0].decisions))

            # The deployed rule is inference state: an evaluation bridge
            # restores it with the weights.
            rl.fpi_lambda, rl.fpi_beta = 2.0, 1.0
            rl._save_checkpoint()
            evaluation = fpi_bridge(testbed(321), directory, train_mode=False)
            self.assertEqual(evaluation.fpi_lambda, 2.0)
            self.assertEqual(evaluation.fpi_beta, 1.0)

    def test_positive_lambda_rule_is_prior_plus_lower_bound(self):
        with tempfile.TemporaryDirectory() as directory:
            core = testbed(123)
            rl = fpi_bridge(core, directory)
            rl.fpi_lambda, rl.fpi_beta = 4.0, 0.5
            CB.advance_one_timestep(core)
            observation = rl.observation_builder.build(
                decision_index=0, simulation_time=1, remaining_deployments=rl.remaining_deployments
            )
            step = rl._advance_recurrent_observation(observation, cache_for_training=False)
            prior, mu, sigma = rl._fpi_rule_inputs(step)
            score = np.where(observation.action_mask, prior + 4.0 * (mu - 0.5 * sigma), -np.inf)
            self.assertEqual(rl._fpi_greedy(observation, step), int(np.argmax(score)))
            rl.fpi_lambda = 0.0
            self.assertEqual(rl._fpi_greedy(observation, step), NPI.route_saving_policy(observation))


class LossTests(unittest.TestCase):
    def test_within_state_loss_ignores_cell_independent_levels(self):
        torch.manual_seed(0)
        samples = torch.randn(4, 3, 5)
        mask = torch.tensor([[1, 1, 1, 0, 1]] * 3 + [[1, 0, 0, 0, 0]], dtype=torch.float32)
        target = torch.randn(4, 5) * mask
        targets = {"target": target, "mask": mask, "weight": torch.ones(4, 3)}
        base = RLBridge._fpi_value_loss(samples, targets)
        shifted = dict(targets, target=(target + 7.0) * mask)
        torch.testing.assert_close(RLBridge._fpi_value_loss(samples, shifted), base)
        member_shift = samples + torch.randn(4, 3, 1)
        torch.testing.assert_close(RLBridge._fpi_value_loss(member_shift, targets), base)
        perfect = target.unsqueeze(1).expand(4, 3, 5) + torch.randn(4, 3, 1)
        self.assertLess(float(RLBridge._fpi_value_loss(perfect, targets)), 1e-10)


class DecisionInterfaceTests(unittest.TestCase):
    def test_catch_up_never_exceeds_accrued_authorizations(self):
        core = testbed(123)
        rl = RLBridge(
            core, train_mode=False, deployment_strategy="heuristic",
            target_active_shelters=5, shelter_action_interval=6, decision_catch_up=True,
        )
        core.rl = rl
        # Block every cell at the t = 1 epoch: the token must be installed at
        # t = 2 by catch-up instead of waiting for (or being lost at) t = 7.
        build = rl.observation_builder.build

        def blocked(**kwargs):
            observation = build(**kwargs)
            if int(kwargs["simulation_time"]) == 1:
                return dataclasses.replace(
                    observation, action_mask=np.zeros_like(observation.action_mask)
                )
            return observation

        rl.observation_builder.build = blocked
        deployments_at = {}
        for step in range(1, int(core.stopTime)):
            CB.advance_one_timestep(core)
            rl.step(simulation_time=step, is_terminal=(step == core.stopTime - 1))
            deployments_at[step] = rl.deployments_made
            self.assertLessEqual(
                rl.deployments_made,
                NPI.accrued_tokens(step, first=1, interval=6, budget=rl.maximum_deployments),
            )
        self.assertEqual(deployments_at[1], 0)
        self.assertEqual(deployments_at[2], 1)
        self.assertGreaterEqual(rl.catch_up_decisions, 1)
        result = rl.end_episode()
        self.assertEqual(result["capacity_tokens_unused"], float(rl.remaining_deployments))
        self.assertEqual(result["catch_up_decisions"], float(rl.catch_up_decisions))

    def test_route_saving_benchmark_is_the_base_policy(self):
        core = testbed(123)
        rl = RLBridge(
            core, train_mode=False, deployment_strategy="route_saving",
            target_active_shelters=5, shelter_action_interval=6,
        )
        core.rl = rl
        checks = []
        original = rl.route_saving_policy.select

        def wrapped(observation, deterministic=True):
            decision = original(observation, deterministic=deterministic)
            checks.append(int(decision.action_index) == NPI.route_saving_policy(observation))
            return decision

        rl.route_saving_policy.select = wrapped
        for step in range(1, int(core.stopTime)):
            CB.advance_one_timestep(core)
            rl.step(simulation_time=step, is_terminal=(step == core.stopTime - 1))
        self.assertTrue(checks)
        self.assertTrue(all(checks))

    def test_scenario_descriptors_extend_the_global_features(self):
        core = testbed(123)
        rl = RLBridge(
            core, train_mode=False, deployment_strategy="heuristic",
            target_active_shelters=3, shelter_action_interval=6, scenario_descriptors=True,
        )
        self.assertEqual(rl.d_global, len(GLOBAL_FEATURE_NAMES) + len(SCENARIO_FEATURE_NAMES))
        CB.advance_one_timestep(core)
        observation = rl.observation_builder.build(
            decision_index=0, simulation_time=1, remaining_deployments=rl.remaining_deployments
        )
        _, global_features = observation.policy_features()
        np.testing.assert_allclose(
            global_features[-len(SCENARIO_FEATURE_NAMES):],
            scenario_descriptor(rl.initial_population, 2, 0.5),
        )


if __name__ == "__main__":
    unittest.main()
